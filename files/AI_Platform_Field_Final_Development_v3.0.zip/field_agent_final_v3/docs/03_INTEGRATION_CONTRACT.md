# 04. 공식 연동 계약 — AP ↔ Field

**이 장은 두 제품 개발 에이전트가 먼저 고정할 네트워크 계약이다.** 실제 서버용 OpenAPI와 인증 공급사 설정은 구현 작업 C01/I00에서 이 규칙으로 생성·검증한다. 경로·필드는 계약 설계이며 현재 호출 가능한 서비스 주소가 아니다.

## 4.1 원본과 복제의 경계

| 데이터 | 원본 | 상대가 보관해도 되는 것 |
|---|---|---|
| Field 가입자·사업체·권한 | Field | 명시적으로 연결한 외부 식별자·권한 범위 |
| AP 가입자·사업체·권한 | AP | 명시적으로 연결한 외부 식별자·권한 범위 |
| Field 서비스·가격·운영시간 | Field | 승인·버전·출처가 있는 지식 스냅샷 |
| AP 직접 등록 FAQ·AI 설정 | AP | 권한 있는 설정 조회 결과; Field 원본으로 자동 덮어쓰기 금지 |
| Field 직접 대화·사진 | Field | 원칙적으로 AP 전달 안 함; 사용자가 별도 전달한 업무만 |
| AP 대화·후속 답변·사진 원본 | AP | Field 통합 문의함의 최소 인덱스, 고객이 전달한 업무 스냅샷 |
| 외부 업무 전달 요청 | AP의 ActionRequest | Field가 접수한 external_request와 수신 증빙 |
| 실제 예약·시간 점유 | Field | AP의 상태 미러·외부 요청 ID·합의 조건 |
| 알림·청구·비용 | 발송/판매 책임 제품 | 상관 ID·결과 메타데이터. 잔액 공유 금지 |
| 매체·배치·홍보 집계 | AP | Field 업무에 필요한 유입 라벨, AP 매체에 별도 승인 집계 |

‘원본은 하나’는 모든 개인정보를 한 제품에 모으라는 뜻이 아니다. AP에서 고객이 Field에 전달하기로 확인한 연락처·요약·첨부는 Field 업무 수행 목적의 **수신 기록**으로 남을 수 있다. 그 데이터와 AP 대화 원본의 보존·정정·삭제 책임은 각각 관리한다.

## 4.2 연결 관계와 식별

초기 연결은 하나의 AP 조직·대표 AI와 하나의 Field 사업체를 명시적으로 매핑한다. AP AI는 다른 일반 웹사이트·공유 링크에도 설치할 수 있다. 다중 Field 사업체에 한 AI를 동시에 매핑해 가격/예약을 섞는 기능은 후속이다.

```text
IntegrationBinding
  connection_id                # 두 서버가 합의한 공개 연동 식별자; 인증 비밀값 아님
  provider_client_id           # 검증된 커넥터 앱
  ap_org_id / ap_agent_id       # AP 자체 ID
  external_org_id              # Field 조직 ID, AP에서는 불투명 참조
  allowed_deployment_ids       # 이 연결의 사이트/배포
  approved_scopes_by_direction
  authorizing_subjects         # 각 제품의 동의한 사용자
  consent_versions / grant_ids
  source_mappings / capabilities
  revision / revoked_at / status
```

상호명·이메일·전화번호로 자동 매핑하지 않는다. API body의 tenant_id, agent_id, 외부 조직 ID는 토큰 바인딩을 바꾸는 권한이 아니다. ID가 유효하더라도 연결 범위 밖이면 거부한다. 새 Field 조직 연결·AI 교체는 새 동의와 변경 영향 검토를 거친다. 기존 요청 ID와 과거 귀속은 유지한다.

## 4.3 두 방향의 권한을 따로 승인

**Field가 AP API를 호출하는 권한과 AP가 Field 업무 API를 호출하는 권한은 다르다.** 동일 토큰을 양쪽 서버에서 받아주지 않는다. 제품 로그인과 OAuth 설치 승인은 별개다.

시작안은 양쪽 제품의 검수된 OAuth 2.0 인가 서버를 사용하는 Authorization Code + PKCE(S256)다. 웹 BFF가 비밀 자격·refresh token을 보관하고 브라우저/설치 코드/localStorage에 넣지 않는다. exact redirect URI, 요청별 state·issuer 검사, 최소 scope, 짧은 access token, refresh rotation을 적용한다. 표준 동작은 검수된 서버/라이브러리로 구현하며 임의 token endpoint를 즉석 작성하지 않는다.[S01]

### 단계별 연결

1. Field 소유자가 연결 시작. Field 세션·조직·최근 인증 상태를 확인하고 연결 transaction/nonce 생성.
2. AP 공식 인가 화면에서 AP 로그인 또는 가입, 연결할 조직·AI 선택, Field가 요청하는 AP 권한 승인.
3. Field BFF가 code를 교환하고 AP issuer·audience·subject·조직 범위를 확인. 이때 기본 AI 설치만 활성화할 수 있다.
4. Field 정보를 가져오거나 예약을 연결하려면 AP가 별도 등록된 client로 Field 인가 화면을 연다. 사업자가 **Field 데이터 읽기·요청 전달 권한**을 별도로 승인.
5. 양쪽 서버가 연결 transaction과 선택된 조직·grant를 검증한 뒤 기능별 active 상태를 합의한다. 둘째 승인이 취소되면 설치만 유지하고 Field 정보/예약 도구는 비활성.
6. 승인된 정보 동기화·서비스 매핑·AI 테스트 후 위젯 활성화. 무료 체험/구독 조건은 별도 표시하며 연결 승인으로 자동 결제하지 않음.

단계 2·4는 하나의 안내 마법사로 연결할 수 있지만 서로의 동의를 몰래 생략하지 않는다. 이메일/카카오 로그인은 각 인가 화면의 인증 수단일 뿐 다른 제품에 자동 로그인하는 공통 쿠키가 아니다.

### AP 발급 → Field 보관 토큰의 범위

| Scope | 허용 | 추가 경계 |
|---|---|---|
| ap.agent.read | 선택한 AI의 공개·상태 정보 | AP 전체 조직 조회 불가 |
| ap.sources.refresh | 이 연결의 승인 정보 갱신 요청 | 임의 source/지식 공개 금지 |
| ap.deployments.manage | 검증된 Field 사이트의 배포 생성·중지 | 다른 외부 사이트 배포 삭제 불가 |
| ap.conversations.read | 이 연결·배포 또는 넘겨받은 업무에 관련된 대화 | AI의 다른 사이트 대화를 전부 조회하지 않음 |
| ap.conversations.reply | 연결 대화에 동의한 사업자의 직접 답변 | 설치용 백그라운드 credential에는 넣지 않음 |
| ap.events.read | 이 연결 사건·실패 메타데이터 | 매체/타 연결 이벤트 조회 불가 |
| ap.connection.revoke | 이 연결 해제 | AI 전체 삭제·계정 해지 불가 |

사람 답변에는 최근 유효한 **그 사람의 AP 위임 토큰**을 사용한다. Field membership만 존재하는 다른 직원에게 소유자의 AP 토큰을 대리 사용하지 않는다. 초기 소유자 1명 기준이며 후속 직원은 각자 AP membership·권한 연결이 필요하다. 백그라운드 동기화·배포·수신 이벤트용 installation grant는 사람 답변 scope와 분리한다.

### Field 발급 → AP 보관 토큰의 범위

| Scope | 허용 | 금지 |
|---|---|---|
| field.facts.read | 승인된 사업 정보·서비스·가격·FAQ | 사이트 초안·내부 메모·전체 고객 목록 |
| field.availability.read | 서비스별 요청 가능 구간 | 예약자 신원·점유 사유 |
| field.requests.create | 고객이 확인한 문의/예약 요청 생성 | 실제 예약 확정·가격 변경 |
| field.requests.read | 이 연결에서 생성한 작업/제안/결과 | 다른 경로 요청 열람 |
| field.proposals.respond | 고객이 특정 제안에 직접 동의/철회한 결과 전달 | LLM의 임의 수락 |
| field.notification_route.read | 연결된 작업 사건의 현재 알림 책임 조회 | 임의 채널 발송 |
| field.connection.revoke | 이 연결 취소 | Field 사이트·예약·구독 삭제 |

`field.reservations.confirm`, 사이트 공개, Field 관리자, 결제, 원장 SQL 범위는 어떤 AP 도구에도 부여하지 않는다. Field도 AP 조직을 대신해 AI를 임의 공개하지 않는다.

초기 제안값: access token 10분, authorization code 60초·1회, refresh token은 rotation·재사용 탐지·명시 만료. 실제 유효기간은 선택한 인가 서버 제약과 보안 검토 후 고정한다. revoke endpoint·연결 상태 검사를 같이 두고, 단순히 refresh token만 지워 남은 access token을 계속 허용하지 않는다.[S02]

## 4.4 연결 상태와 도구 발견

제품의 단일 `connected=true` 대신 기능별 상태를 가진다.

| 상태 | 의미·동작 |
|---|---|
| pending_ap_consent | AP 권한 승인 전. 기존 Field는 정상 |
| install_only | AP 위젯 사용 가능. Field 데이터/예약 권한 없음 |
| pending_field_consent | 역방향 기능 승인 대기 |
| syncing / review_required | 데이터 동기화·사업자 정보 승인 대기 |
| active | 허용된 기능의 준비 상태 검수 완료 |
| degraded | 일부 API/동기화 실패. 이용 가능한 기능만 표시 |
| suspended / expired | 제재·구독·인가 사유로 해당 연결 기능 제한 |
| revoking / revoked | 로컬 사용 즉시 차단, 원격 폐기 재시도; 업무 원본 보존 |

`GET /integrations/v1/capabilities`는 `facts.read`, `availability.read`, `request.create`, `proposal.respond` 지원 여부와 스키마 버전을 반환한다. AP가 Field 전용 bool/SQL로 판단하지 않는다. 연결이 없는 AI는 기능 발견을 호출할 필요 없이 자체 FAQ·상담만 실행한다. 외부 앱이 예약 기능을 지원하지 않아도 커넥터와 AI가 실패하지 않게 한다.

## 4.5 승인 정보 동기화와 최신성

### 원본과 승인 흐름

Field 변경 승인 → FieldCatalogRelease(version N) + outbox 생성 → signed facts.changed 이벤트 → AP가 해당 연결 API로 snapshot 조회 → source revision/hash 검증 → AP KnowledgeDraft에 변경안 → AP 사업자가 영향 확인 후 승인 → 새 AP KnowledgeRelease.

초기 기본값은 **가져온 변경을 AP에서도 검토 후 활성화**다. 최초 연결 후 모든 미래 가격을 자동 승인하는 정책은 기본으로 켜지 않는다. Field에서 한 승인과 AP 지식 공개 승인은 다른 제품의 별도 행위다. Field 연결 화면에서 AP 변경 검토로 이동하거나 AP의 공식 승인 화면을 사용할 수 있다.

Source 필드:

```text
source_id, provider, connection_id, external_org_id
source_revision, entity_versions, content_hash, published_at
fetched_at, approved_source_revision, ap_knowledge_release_id
state: current | pending_review | stale | unavailable | revoked
```

여기서 source_revision은 외부 제품이 부여한 비교 가능한 버전이고 AP KnowledgeRelease의 버전과 같지 않다. 순서가 뒤집힌 이벤트는 원본 상태를 과거로 돌리지 않는다. 누락된 revision은 snapshot 재조회로 복구한다. 같은 source/version/hash는 멱등, 동일 version+다른 hash는 integrity_conflict로 격리한다.

### 가격·가용성의 엄격한 규칙

제품 간 한 DB 트랜잭션은 존재하지 않는다. 일반 소개·FAQ는 승인한 캐시와 마지막 확인 시각으로 안내할 수 있으나, **연결된 서비스의 가격·활성 상태·예약 조건을 수치로 제시하는 응답은 Field에서 현재 entity revision을 재확인**한다.

- Field 현재 버전과 AP가 승인한 버전이 같으면 근거로 사용한다.
- 다르면 새 값을 미승인 상태로 그대로 답하거나 예전 값을 최신이라고 답하지 않는다. 해당 필드는 검토 필요 안내·사람 문의로 전환한다.
- Field 조회가 실패하면 가격/가능 시간 확정 안내를 하지 않는다. AP 전체 상담실과 다른 native 지식은 계속 이용 가능하다.
- 무관한 다른 서비스의 변경은 해당 서비스 entity version이 동일하면 차단할 필요 없다. entity version을 제공하지 않는 커넥터는 전체 snapshot 버전을 엄격 비교한다.
- 최종 요청 제출에는 고객이 본 서비스 버전·조건 hash를 함께 보낸다. Field가 더 새 조건을 갖고 있으면409 `SOURCE_VERSION_CHANGED`로 최신 확인을 요구한다.

카드·사이트에서 가격을 복사한 정적 문구는 stale 검수 대상이다. 연결된 숫자는 가능한 라이브 바인딩으로 렌더하고, 확인 불가 시 ‘가격 확인 필요’로 바꾼다. 어떤 시점에도 전체 외부 사이트의 캐시가 동시에 바뀐다고 보장하지 않는다.

캐시 일반 확인 간격 5분, 소개자료 stale 24시간, 중요값 라이브 재확인은 제안값/실행 정책이다. 실제 주기와 모델 지연·API 부하를 측정하며 중요값 검사를 조용히 생략하는 최적화는 금지한다.

## 4.6 외부 요청과 예약 전달 — 분산 상태 처리

AP `ActionRequest`는 Field의 예약이 아니다. 외부 전달 원장과 예약 원장을 구분한다.

| AP 상태 | 고객에게 표시 | 다음 동작 |
|---|---|---|
| draft / awaiting_customer | 전달 내용을 확인해 주세요 | 고객의 명시 제출 |
| queued / sending | 문의는 저장됐으며 Field 전달 중 | 멱등 전송 |
| accepted_external | Field에 요청 접수됨, 아직 미확정 | 외부 ID 저장·사업자 응대 |
| delivery_unknown | 전달 결과 확인 중 | 원래 요청 ID로 Field 조회, 새 업무 생성 금지 |
| retryable_failure | 전달 지연, 다시 확인 중 | 같은 키로 제한 재시도 |
| rejected | Field가 접수하지 못함/조건 재확인 필요 | 원본 유지·고객 수정/직접 문의 |
| canceled_before_delivery | 고객이 전달 전 취소 | 큐 전송 차단; 이미 수신됐다면 외부 철회 요청 |

```json
{
  "action_request_id": "ar_example_001",
  "connection_id": "con_example_001",
  "kind": "reservation_request",
  "origin_conversation_id": "ap_thread_example",
  "external_service_id": "field_service_example",
  "expected_service_revision": 7,
  "customer": {"name": "테스트 고객", "phone": "01000000000", "verified": false},
  "request": {"mode": "preferred", "timezone": "Asia/Seoul", "preferences": ["2026-10-10 오전"]},
  "consent": {"version": "transfer-v1", "record_id": "consent_example", "confirmed_at": "2026-09-24T10:00:00Z"},
  "summary": "세탁기 청소 일정 문의",
  "attachment_refs": [],
  "source": {"provider": "agent-platform", "deployment_id": "dep_example", "is_test": true}
}
```

위 값은 테스트용 예시다. 외부 요청에는 고객 최종 확인의 감사 레코드·body hash를 묶고 signed/authenticated server 요청으로 전달한다. 이것은 휴대전화 실명 인증 증명이 아니다. `verified=false`는 수신 Field에도 보존한다. 프론트가 보낸 `is_test=false`를 신뢰하지 않고 서버의 테스트 세션에서 결정한다.

Field 처리:

1. 인증·scope·connection·동의 참조·대상 서비스·최신 조건·외부 요청 hash 검증.
2. `UNIQUE(provider, connection_id, action_request_id)`로 동일 업무를 하나만 수락. 같은 ID·다른 body면409.
3. Field 트랜잭션에 external_work_request·예약 requested·업무 수신 증빙·outbox 저장. 예약은 미확정이므로 점유 없음.
4.201/200 응답에 `external_request_id`, `reservation_id`(해당 시), `status=requested`, `version` 반환.
5. AP는 external ID가 확인된 경우에만 ‘Field 접수 완료’로 전환. 타임아웃은 unknown이며 같은 키로 조회/재시도.
6. 사장님이 Field 자체 승인 API에서 confirm. DB 충돌 검사 후 이벤트 발행. AP는 상태 미러만 갱신.

수신 조회 API는 AP가 저장한 action_request_id로 이미 수락된 건을 찾을 수 있어야 한다. 큐 재시작·이벤트 역순·연속 클릭도 별도 예약을 생성하지 않는다. 인터넷 전체에 exactly-once delivery가 있다고 가정하지 않고 at-least-once 전달과 멱등 업무 처리로 설계한다.

사진은 기본적으로 AP 원본의 짧은 권한 링크를 Field 서버가 인증된 API로 받아 고객이 전달에 동의한 자산만 복사·검사한다. 외부 body가 지정한 임의 URL을 fetch하지 않는다. Field가 수락한 업무 첨부는 자기 비공개 저장소에서 목적·출처·보존을 기록한다. 일부 첨부 복사가 실패하면 상태를 표시하고 본문 접수 성공과 구분한다.

## 4.7 대화·업무 UI와 고객 접근

AP가 원본인 대화는 Field BFF가 위임 API로 읽는다. 메시지 전송은 AP가 원본 event_id를 발급하고 AP에서 저장·AI 인계·알림을 처리한다. Field는 AP 문장을 자기 DB에서 따로 편집하거나 AP 장애 중 성공 메시지를 생성하지 않는다.

Field 직접 문의는 Field 원본이며 AP에 자동 이관하지 않는다. 고객 대화는 생성 제품의 상담 도메인에 남긴다. 제품 사이에 HttpOnly 쿠키를 공유하거나 전화번호로 로그인시키지 않는다.

Field에 확정된 예약이 있는 AP 고객에게 독립 Field 예약 확인 경로가 필요하면, **이미 인증된 AP 대화 권한 + 정상 connection + 연결된 reservation_id를 서버 간 검증**한 뒤 1회·짧은 수명·Field audience handoff를 발급한다. Field는 이를 자신의 예약 범위 capability로 교환한다. 이후 AP가 중단돼도 해당 Field 권한으로 예약 확인·변경 요청을 할 수 있다. 알림 링크나 외부 ID만으로 권한을 발급하지 않는다.

정상 연결 시 대화는 AP에서 유지하고 예약 상태·제안 UI는 허용 API를 사용한다. AP 장애/해제 후 새 연락을 위한 Field 후속 스레드가 필요하면 새 원본이라는 사실을 표시하고, 기존에 수신한 업무/예약과만 연결한다. AP 과거 대화 원문을 몰래 복제하지 않는다. 양방향 자동 transcript sync는 제외한다.

## 4.8 알림의 단일 책임

| 사건 | 기록 원본 | 정상 연결의 외부 알림 책임 |
|---|---|---|
| AP 일반 문의 제출/고객 추가 메시지 | AP | AP → 사업자 |
| AP 대화에서 사업자 답변 (AP 화면 또는 Field API) | AP | AP → 고객 |
| Field 직접 문의/답변 | Field | Field |
| AP가 넘긴 Field 예약 요청 수락 | Field 업무 + AP 전환 원장 | AP 한 번. Field 미러 생성에 별도 고객/사업자 알림 중복 금지 |
| 연결 AP 예약의 Field 확정/제안/변경 | Field | AP가 외부 사건을 기록한 뒤 고객 통지 |
| Field 직접 예약의 확정/변경 | Field | Field |
| 각 제품의 결제/보안/서비스 장애 | 해당 제품 | 해당 제품 |

원본 이벤트마다 `notification_owner_product`, `origin_event_id`, `connection_id`, `route_generation`을 저장한다. AP 대화/사용량 알림은 AP 구독에, Field 직접 업무는 Field 구독에 귀속한다. Field가 대신 AP 대화에 답변해도 AP 응답/메시지 비용을 Field 원장에 중복 차감하지 않는다.

Field→AP 사건이 지연되면 Field는 ‘예약 확정됨·고객 알림 전달 대기’를 표시한다. AP 장애를 이유로 Field가 동일 사건의 SMS를 자동 병행 발송하지 않는다. 원격 수신 ACK는 알림 최종 발송 성공이 아니다. AP가 처리·발송 결과 상태를 기록하고 Field는 정해진 API/이벤트로 조회한다.

연결 예약 사건의 발송 직전 AP는 Field의 알림 route/current generation·연결 상태를 확인한다. 확인할 수 없으면 보류한다. AP 자체 일반 대화의 알림은 Field 확인 없이 처리한다. 이 구분으로 AP 독립 운영을 유지한다.

**연결 해제 시 자동 발송 소유권 전환은 하지 않는다.** 기존 예약은 Field에 남기고 ‘직접 연락/알림 경로 재설정 필요’로 안내한다. Field의 유효한 고객 접근 경로와 필요한 고지/동의를 마련한 뒤 새 generation을 발급해 명시적으로 전환한다. 이전 generation에 속한 queued 이벤트는 폐기/대조 후 처리한다. 이미 공급사에 전달된 미상 메시지는 조회로 정리하고 곧바로 대체 발송하지 않는다. 긴급한 경우 사장님이 전화 등으로 직접 연락한 사실을 기록한다.

## 4.9 이벤트·멱등·재조정

두 제품은 각각 로컬 업무 commit+outbox를 같은 DB 트랜잭션에 저장한다. 원격 웹훅 수신은 서명 확인 후 inbox 원장에 durable 저장한 뒤202를 반환한다. 아직 저장하지 못하면2xx를 주지 않는다. 업무 처리·알림 생성은 이후 멱등 수행한다.

```json
{
  "spec_version": "1.0",
  "event_id": "evt_example_001",
  "event_type": "field.reservation.confirmed",
  "source_product": "field",
  "connection_id": "con_example_001",
  "aggregate_type": "reservation",
  "aggregate_id": "field_reservation_example",
  "aggregate_version": 3,
  "occurred_at": "2026-09-24T10:05:00Z",
  "correlation_id": "ar_example_001",
  "data": {"resource_id": "field_reservation_example", "status": "confirmed"}
}
```

웹훅 payload에는 원문·전화·주소·사진 URL·access token을 넣지 않는다. 필요한 원본은 scope가 있는 API로 조회한다. 등록된 client/connection과 source를 검증하며 body source 문자열을 믿지 않는다. `UNIQUE(source_product,event_id)`로 중복 제거하고 aggregate_version 역행·누락 시 최신 원본을 재조회한다.

초기 서명 계약은 제품 간 사전 등록된 연결별 secret의 **HMAC-SHA256**이다. 자체 프로젝트 계약이며 RFC와 동일한 메시지 서명 표준이라고 부르지 않는다. `X-Event-Id`, `X-Timestamp`(Unix seconds), `X-Key-Id`, `X-Signature`를 사용하고 서명 원문은 `timestamp + "." + event_id + "." + raw_body_bytes`다. 상수시간 비교, body/header event 일치, ±5분 시간창, 최대 body 크기, 키 교체를 검수한다. 재전송은 같은 event_id와 새 timestamp/서명으로 처리한다. secret은 브라우저에 제공하지 않는다.

일시 오류는 backoff+jitter, 한도 초과는 Retry-After,401/403은 재인가 또는 권한 조치로 구분한다. schema/동의/버전 오류를 무한 재시도하지 않는다. 제안값 8회·24시간 후 실패함,5분 단위 누락 재조정. 실제 재시도 횟수와 SLA는 실행 정책이다.

## 4.10 위젯·동일 조건 설치

Field는 공개 AP SDK를 설치한다. AP의 서버 프레임 응답은 CSP frame-ancestors로 허용 origin을 제한한다. meta 태그로만 설정하지 않는다.[S04] postMessage는 origin·source·nonce·허용 스키마·크기를 검사하고 부모에 대화/권한 비밀값을 전달하지 않는다.[S03]

일반 외부 사이트와 Field 모두 API 공개키와 세션 범위가 같다. origin 확인만을 사용자 인증이나 서버 abuse 방지로 간주하지 않는다. 공개 세션 발급·비용·사용량 제한과 risk 검사를 같이 수행한다. 설정할 수 있는 URL·redirect는 등록된 HTTPS 경로로 제한하고 SSRF/내부망/metadata 주소 fetch를 금지한다.

`owned_embed` 설치는 campaign_id, publisher_id 없이 동작한다. `partner_card`만 campaign release·publisher approval·slot 검사가 필요하다. Field도 그 구분을 따르며 모든 위젯을 광고로 처리하지 않는다.

## 4.11 연결 해제·장애·삭제

| 상황 | AP | Field |
|---|---|---|
| Field 전체 장애 | AP native 상담/다른 사이트는 정상. Field 중요 사실·예약 도구는 중단 | 자체 복구. AP와 무관한 데이터 보호 |
| AP 전체 장애 | 원격 AI/대화 불가를 정확히 표시 | 사이트·직접 문의·달력·기존 예약 정상. AP 전송은 미전송/대기 |
| 연결 revoke | 연결 source/도구/Field 배포·위임 권한 중지; 다른 native/외부 배포는 유지 | 토큰 폐기·원격 읽기/쓰기 차단; 직접 업무·수신 예약 보존 |
| AP 구독 종료 | 신규 AI/배포 제한·기존 상담 정리 | Field 구독·예약은 유지, 알림 경로 재설정 안내 |
| Field 구독 종료 | 다른 사이트의 AP는 유지, Field 신규 업무는 제한 상태 표시 | 자기 종료 정책·기존 예약 정리 |
| 한쪽 삭제 요청 | 해당 제품 원본·권한·법적 보존별 처리 | 이미 적법하게 수신한 원본의 목적·보존을 별도 판단 |

revoke 요청을 받은 서버는 로컬 실행을 먼저 차단하고 원격 폐기 요청을 durable 재시도한다. 원격이 오프라인이라 즉시 모든 토큰이 사라졌다고 표시하지 않는다. 사용 시 연결 상태/만료를 검증하며 유효한 요청도 scope 밖이면 거부한다. 법적 권리·약관상 필요한 양쪽 데이터 정정·삭제 요청은 추적 ID로 분리 전달하고 결과를 기록한다. 상대 동의 없이 전체 조직을 삭제하는 API는 없다.

Field source가 해제되면 그 값의 AP 사용을 중단한다. 데이터가 공개 정보였다는 이유로 AP native로 조용히 전환하지 않는다. 계속 쓰려면 권리와 최신성을 확인하고 AP 직접 등록·승인 절차로 새 source를 만든다. 다른 native source가 준비돼 있다면 그 범위의 상담은 유지한다.

## 4.12 공개 연동 API 최소 목록

### AP 제공 — Field 및 검증된 외부 통합자가 사용

| 경로 | 권한/필수 입력 | 결과 |
|---|---|---|
| GET /integrations/v1/me | AP 위임 token | 허용 조직·AI·scope·grant 상태 |
| POST /integrations/v1/connections | 동의 transaction, 선택 AI | binding, 허용 기능 |
| POST /integrations/v1/connections/{id}/source-refreshes | ap.sources.refresh, 예상 source 버전 |202 sync_job |
| POST /integrations/v1/deployments | ap.deployments.manage, owned origin·agent | 설치 준비; 검증 후 활성 |
| GET /integrations/v1/conversations | read, 연결 제한 cursor | 최소 목록·출처·remote 상태 |
| GET /integrations/v1/conversations/{id}/messages | read, 범위·cursor | 원본 sequence |
| POST /integrations/v1/conversations/{id}/replies | user reply, message·revision·idempotency | 원본 message ID·저장/알림 상태 |
| POST /integrations/v1/connections/{id}/revoke | 해당 연결 manage | 로컬 차단·원격 revoke 상태 |
| POST /integrations/v1/webhooks/field | 등록 서명·event envelope |202 durable inbox receipt |
| GET /integrations/v1/events/{id}/delivery | 연결 사건 read | processed/notification status |

### Field 제공 — AP 커넥터 및 동일 계약의 외부 앱이 사용

| 경로 | 권한/필수 입력 | 결과 |
|---|---|---|
| GET /integrations/v1/capabilities | Field 위임 token | 이 연결에서 지원/허용된 도구 |
| GET /integrations/v1/facts | field.facts.read, ETag/version | 승인 snapshot·entity version·hash |
| GET /integrations/v1/availability | scope, service_id·revision·from/to | 요청 가능 구간만 |
| POST /integrations/v1/external-requests | create, ActionRequest·consent·idempotency | external_request_id·requested 상태 |
| GET /integrations/v1/external-requests/by-source/{actionId} | read, binding | 타임아웃 뒤 기존 수락 확인 |
| GET /integrations/v1/external-requests/{id} | read, 연결 리소스 | 최신 상태·version·제안 |
| POST /integrations/v1/external-requests/{id}/customer-decisions | respond, exact proposal·customer proof | 동의/철회 상태. 확정 아님 |
| GET /integrations/v1/external-requests/{id}/notification-route | route.read | 소유 제품·generation·허용 여부 |
| POST /integrations/v1/customer-handoffs | read+범위 고객 증빙, 예약 ID |1회·Field audience 접근 교환 |
| POST /integrations/v1/connections/{id}/revoke | manage | 로컬 차단·원격 폐기 상태 |
| POST /integrations/v1/webhooks/agent | 등록 서명 |202 durable inbox receipt |

write의 Idempotency-Key는 제품+client+connection+operation 범위다. 같은 키·다른 body는409. 변경 객체에는 If-Match/expected_revision을 쓴다.400 입력,401 인증,403 권한,404 안전한 미존재,409 충돌/조건 변경,410 해제/만료,429 사용량,503 일시 장애를 명확히 반환한다. 응답은 `request_id`, `operation_id`(비동기), `state`, `retryable`을 포함하고 개인정보를 오류 문구에 넣지 않는다.

### 계약 변경 정책

API major 버전과 event `spec_version`은 문서 release v3.0과 독립이다. enum 추가도 exhaustive client 영향 검토가 필요하다. 호환 가능한 추가는 contract test 후 적용하고 breaking 변경은 새 API major/dual support/이행 계획으로 처리한다. 최소 이전 지원 버전·지원 기간은 계약 정책으로 고정한다. 런타임은 모르는 필드를 조용히 권한으로 취급하지 않는다.

AP+Field 두 코드베이스가 공유할 수 있는 것은 versioned OpenAPI·JSON Schema에서 생성한 클라이언트와 명세다. domain service·repository·DB 타입·내부 ORM 모델은 공유하지 않는다.
