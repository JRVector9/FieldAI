# TASKS — 독립 제품 개발 작업 보드 v3.0

**총 46개 작업. 모든 상태는 planned이며 실제 구현/테스트 완료를 의미하지 않는다.**

C=계약/인프라, A=AP, F=Field, I=연동, D=배포·매체, R=회귀/이행. 이전 T00~T23 통합 작업표를 대체한다. 한 작업을 에이전트 한 번의 실행으로 끝내야 한다는 시간 추정은 아니다. 필요하면 같은 부모 ID 아래 하위 작업으로 나눈다.

| ID | 제품 | 작업 | 선행 | 필수 산출·검수 | QA 연결 |
|---|---|---|---|---|---|
| C00 | 계약/조율 | 저장소·실제 구현·위험 인벤토리 | 없음 | 기존 데이터/코드 유무·권한·보존·변경 범위 ADR | QA115, QA116 |
| C01 | 계약/조율 | 제품 경계·OpenAPI·이벤트·상태·QA 고정 | C00 | B01~B12·양방향 scope·필드·오류 계약·구버전 대응 | QA121~QA160 |
| C02 | 인프라 | 독립 배포/DB/큐/키/CI 프로필 | C01 | AP-only·Field-only 실행과 import/권한 제한 | QA123, QA124 |
| C03 | 디자인 | 공통 무상태 UI·역할별 라우트 설계 | C01 | 14px·모바일·제품 이동·비연결/오류 상태 | QA57, QA58, QA119 |
| A00 | AP | AP 계정·조직·DB·권한 기반 | C02 | 자체 이메일/카카오·세션·AP migrations·outbox | QA01~QA06, QA125 |
| A01 | AP | 직접 지식·서비스·승인 버전 | A00 | source 출처·revision·KnowledgeRelease | QA22, QA81, QA134 |
| A02 | AP | 자체 비회원 접수·대화·사진·접근 | A00 | Field 없는 first-party intake·확인키·합성 테스트 | QA16~QA20, QA41 |
| A03 | AP | 자체 문의함·사람 인계·답변 | A02 | 대화 원본·mode·internal note·단일 발송 이벤트 | QA21, QA41, QA144 |
| A04 | AP | 실제 AI 안내·테스트·가드레일 | A01, A03 | 모델 어댑터·근거·도구 선택·예산·실패 대체 | QA22~QA24, QA117 |
| A05 | AP | 상담 링크·기본 외부 위젯·handoff | A04, C03 | campaign/publisher 없는 설치·origin·기본 SDK | QA94, QA97~QA102, QA127, QA128 |
| A06 | AP | 독립 메시지·푸시·대체발송 | A03 | 실제 공급사·한 발송 주체·원장·미상 처리 | QA35~QA40 |
| A07 | AP | 독립 구독·크레딧·가격 동의 | A00 | AP-only billing·갱신/해지·공급사 검수 | QA42~QA46, QA126, QA146 |
| A08 | AP | AP 관리자·보존/삭제·백업·신고 | A00, A06, A07 | 원본 보존·AP 권한·복구·운영 runbook | QA47~QA49, QA157 |
| A09 | AP | 공식 통합자 API·인가·외부 client 계약 | A01, A03, A05 | AP OAuth server·scope·위임 API·등록 client·문서 | QA129~QA133 |
| A10 | AP | AI Core 단독 실검수 | A05, A06, A07, A08, A09 | Field 없는 실제 외부사이트/실알림/구독·QA 증빙 | QA117, QA121, QA127, QA128 |
| A11 | AP | AI Core 독립 공개 승인 | A10 | G-A1~G-A3·G-L1 적용 증빙·배포/되돌림 | QA121, QA120 |
| F00 | Field | Field 계정·조직·DB·권한 기반 | C02 | 자체 이메일/카카오·세션·Field migrations·outbox | QA01~QA06, QA125 |
| F01 | Field | 사업/서비스·원본 카탈로그 버전 | F00 | 구조화 가격·두 예약 설정·FieldCatalogRelease | QA53, QA77 |
| F02 | Field | 5단계·템플릿·직접 편집·미디어 | F01, C03 | 실입력·다중페이지·사진·재개·모바일 | QA51~QA62, QA70, QA71 |
| F03 | Field | 사이트 제작 LLM·취소·충돌 | F02 | AP없는 제작 어댑터·JSON 제한·작업/비용 | QA54, QA63, QA64, QA122 |
| F04 | Field | 사이트 공개·복구·기본/자체 도메인 | F03 | Field내 원자성·실제 TLS·AP영향 분리 | QA07~QA15, QA65~QA75 |
| F05 | Field | 직접 문의·비회원·사진·후속 접근 | F00, F01 | AP없어도 저장·capability·안전 연락 | QA17~QA20, QA41, QA143 |
| F06 | Field | 직접 문의함·답변·내부 메모 | F05 | 자체 대화 원본·server 상태·outbox | QA41, QA143 |
| F07 | Field | 두 예약 방식·달력·수동 일정 | F01, F06 | 요청/확정·DB충돌·변경·취소·snapshot | QA25~QA34 |
| F08 | Field | 자체 알림·대체발송·이력 | F06, F07 | 자체 공급사 검수·미상·중복·한도 | QA35~QA40 |
| F09 | Field | 구독·관리자·보존·복구 | F00, F04, F08 | 독립 청구/해지·정리모드·Field 운영실 | QA42~QA49, QA146, QA157 |
| F10 | Field | Field Core 단독 실검수 | F04, F07, F08, F09 | AP 없는 사이트→직접문의→예약·실알림·구독 | QA50, QA80, QA122 |
| F11 | Field | Field Core 독립 공개 승인 | F10 | G-F1~G-F3·G-L1 적용 증빙·배포/되돌림 | QA120, QA122 |
| I00 | 연동 | Field 역방향 인가·OAuth 양방향 마법사 | A09, F00 | 서로 다른 token/audience·거부/취소·scope | QA129~QA132 |
| I01 | 연동 | 조직·AI·actor·source 매핑·기능 발견 | I00, A01, F01 | connection ledger·설치만/부분연결·허용리소스 | QA130, QA133, QA134 |
| I02 | 연동 | 승인 정보 sync·최신성·재조정 | I01, F04 | Field source→AP 검토·revision/hash·live 중요값 | QA84, QA135~QA138, QA156 |
| I03 | 연동 | Field 사이트에 외부 SDK 설치 | I01, A05, F04 | 일반외부사이트와동일한 public 계약·origin | QA86, QA94, QA128 |
| I04 | 연동 | 외부 문의/예약 요청·고객 인계 | I01, A02, F07 | 동의·idempotence·unknown·수신 snapshot·Field capability | QA139~QA142, QA153, QA155 |
| I05 | 연동 | Field 문의 통합뷰·AP 답변·알림 소유 | I04, A03, A06, F06, F08 | 원본 API·reply actor·event route·미전달 표시 | QA144, QA145, QA148, QA149 |
| I06 | 연동 | 해제·부분 장애·구독 종료·삭제 | I02, I03, I05 | 양방향 revoke·원격대기·업무보존·새 알림경로 | QA146, QA150~QA155 |
| I07 | 연동 | fault injection·권한/계약 회귀 | I06 | 복수 origin·결과미상·서명재생·scope공격·version 호환 | QA131, QA132, QA140, QA158, QA159 |
| I08 | 연동 | Field Connector 공개 승인 | I07, A11, F11 | G-I1~G-I3·동일 외부 client 계약·고객 E2E | QA50, QA80, QA160 |
| D00 | 배포/매체 | AP 홍보 카드·검토·공개 | A01, A04 | campaign/knowledge 참조·광고표시·revision | QA87~QA91 |
| D01 | 배포/매체 | 매체 조직·도메인·광고 위치 | A00, A09 | 매체 RBAC·소유 증명·slot·AP 관리 | QA92, QA94, QA95 |
| D02 | 배포/매체 | 정확한 카드 버전 배치 승인 | D00, D01 | 사업자공개와매체승인분리·상태·중지 | QA90~QA96 |
| D03 | 배포/매체 | 외부 기사 카드·AP 접수 전환 | A05, D02 | Field 없이 광고 대화→AP 접수·권한/고지 | QA97~QA103, QA118 |
| D04 | 배포/매체 | 성과·개인정보 없는 집계·export | A02, D03 | source event·데모제외·작은집단/차분억제 | QA104~QA107 |
| D05 | 배포/매체 | Distribution 독립 검수·출시 | D04, A10 | G-D1~G-D2·제휴 증빙·AP만으로완료 | QA108~QA114, QA118 |
| R00 | 검수/이행 | 기존120개 재귀속·추가40개 검수 추적 | C01 | QA01~QA160적용제품·게이트·기존변경근거 | QA01~QA160 |
| R01 | 검수/이행 | 기존 서버 존재 시 이행·없으면 N/A 증빙 | C00, I06 | 원본분류·동의·건수·백업·전환·복구 | QA115 |
| R02 | 최종 | 두제품+연동+매체 전체 최종 인수 | A11, F11, I08, D05, R00, R01 | G-S1·독립/연결회귀·릴리스 evidence·운영 인계 | QA120, QA160 |

## 실행 순서와 독립 출시

**C00 → C01 → C02/C03 → A 트랙과 F 트랙 병렬.** AP Core는 A11에서 Field/매체 없이 출시할 수 있다. Field Core는 F11에서 AP 없이 출시할 수 있다. I 트랙은 두 제품의 공개 계약을 이용해 통합하며 I08에서 별도로 승인한다. D05는 AP의 매체 확장 출시이며 Field/연동을 선행으로 요구하지 않는다.

AP A09가 일반 통합자에게 제공하는 인가/API이고, I00는 Field가 외부 리소스 서버로 제공하는 역방향 구현이다. 이를 서로의 런타임 의존으로 합치지 않는다. 실제 API/인증을 구현하기 전에 UI 목업을 만들 수 있으나 해당 task를 verified로 표시할 수는 없다.

R01은 운영 서버/DB가 없다는 인벤토리 증빙이 있으면 not_applicable로 종료한다. 있는 경우 이행 검수는 생략하지 않는다. R02는 모든 제품의 기존 요구가 충족됐는지 검수하며 독립 Core 출시에 영향을 주는 선행 작업이 아니다.

## 모든 작업의 Definition of Done

UI·API·도메인·DB·권한·이벤트·사용량·오류·보안·테스트·롤백이 해당 범위에서 연결되어야 한다. `implemented`는 코드 완료이며 `verified`는 실행 증빙이 있는 상태다. 외부 승인 부재는 blocked_integration이다. QA의 제품별 적용을 생략하거나 다른 제품의 완료로 대체하지 않는다.

API/스키마 변경은 Coordinator가 계약을 승인하고 AP/Field 각 consumer 테스트를 통과한 뒤 병합한다. 공통 migration을 두 제품이 동시에 쓰지 않는다.

## 에이전트별 소유 경로

| 담당 | 기본 소유 | 변경 금지/협의 |
|---|---|---|
| Coordinator | 공개 계약·상태·작업·ADR | DB 직접 병합은 제품 담당 리뷰 |
| AP Agent | agent-web/worker/domain/db | Field 코드 import 금지 |
| Field Agent | field-web/worker/domain/db | AP 코드 import 금지 |
| Connector Agent | generated clients·integration adapter·contract tests | 상대 내부 repository 호출 금지 |
| Distribution Agent | AP campaign/publisher/embed | Field reservation 구현 금지 |
| Reliability | CI·인프라·복구·security/e2e | 게이트 우회·skip을 pass로 처리 금지 |

## 작업 카드 기본 형식

```text
Task / Parent / Product:
State / Owner:
Dependencies / Requirement / QA / Gate:
Allowed paths / Forbidden imports:
Contract inputs and outputs:
Acceptance and failure cases:
Tests run / environment / commit / evidence:
Provider approvals / blockers:
Migration / rollback / handover:
```
