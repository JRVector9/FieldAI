# 독립 AI 플랫폼 × Field
## 최종 개발 계획 v3.0

**2026년 9월 24일 · 개발 에이전트 인계용 · 제품별 독립 출시 및 정식 연동 기준**

> **AI 플랫폼은 Field의 하위 기능이 아니다. Field를 포함한 외부 서비스가 설치하는 독립 제품이다.**

이번 최종본은 기존 통합 PRD v2.0을 대체한다. 기존 21개 결정과 홈페이지 셀프 제작·역할별 UI를 유지하고 제품 경계·DB·계정·과금·배포·연동 계약을 개정했다.

| 산출물 | 상태 |
|---|---|
| 제품 | 독립 Agent Platform / 독립 Field / 공식 연동 계약 |
| 작업 | 46개 계획 작업, 제품별 독립 DAG |
| 인수 | 160개 실서비스 인수 기준, 현재 미실행 |
| 이번 범위 | 개발 문서·계약 예제·보고서. 운영 서버·새 UI 구현은 아님 |
| 기존 시안 | UI v3는 시각/흐름 참고. 제품별 이전 요구는 06장 적용 |

### 읽는 순서

제품 책임자는 01장, 각 개발자는 02·03장과 04장, 배포 담당자는 05장, UI 담당자는 06장, QA는 07장, 개발 에이전트는 마지막 TASKS·AGENTS 지침을 함께 읽는다. [변경 이력](CHANGELOG_v3.0.md)과 [분할 문서](README.md)를 함께 제공한다.

---

## 01. 최종 제품 구조와 변경 기준

**기준일 2026-09-24 · 개발 계획 v3.0 · 이전 개발안 v2.0을 대체**

> 독립 AI 플랫폼은 누구나 가입해 자기 사업 AI를 만들고 외부에 설치하는 제품이다. Field는 그 AI 플랫폼의 내부 상위 서비스가 아니라, 공개된 연동 계약으로 AI를 설치하는 첫 번째 외부 고객 서비스다.

### 1.1 문서의 적용 수준

| 구분 | 의미 |
|---|---|
| 사용자 확정 | 기존 21개 선택, 사업자 셀프 홈페이지 제작, 역할별 화면 유지, Firsthand식 독립 AI 제품, Field의 외부 연동 관계 |
| 실행 설계 | 추가 설문 없이 개발 에이전트가 구현할 수 있게 정한 제품 경계·상태·API·데이터·오류 처리. 변경 시 ADR과 영향 검토 필요 |
| 제안값 | 기간·한도·성능·보존·집계 하한. 실측이나 가격 확정이 아니며 정책 설정으로 관리 |
| 출시 게이트 | 실제 계정·PG·메시지·도메인·보안·복구·연동 검증과 책임자 승인 |
| 이번 산출물 | 개발 문서와 계약 예제. 운영 서버 코드, 새 UI 프로토타입, 실제 공급사 승인 결과가 아님 |

`Agent Platform` 또는 `AP`는 독립 AI 제품의 임시 명칭이다. 최종 상표·도메인이 아니다. Firsthand는 브랜드 AI·외부 배포라는 제품 개념의 참고 대상일 뿐, Firsthand API 구매·코드 이용·기능 완전 동등성을 전제하지 않는다.[S06]

우선순위는 **최신 사용자 확정 → 이 v3.0의 명시 규칙 → 개정된 제품별 명세·연동 계약 → 과거 시안의 시각 표현**이다. v2.0의 공유 DB·공유 조직·한 구독·통합 출시 의존성과 UI v3의 하나의 역할 전환기는 더 이상 운영 아키텍처 기준이 아니다.

### 1.2 두 제품, 한 공개 연동 계약

| 항목 | Agent Platform — 독립 AI 서비스 | Field — 사이트·업무 운영 서비스 |
|---|---|---|
| 핵심 고객 | 기존 사이트 운영 사업자, 자체 사이트 없는 사업자, 기업, 제휴 매체 | 다양한 1인 사업자, 이후 기존 출장·AS 업체 |
| 첫 행동 | 내 사업 AI 만들기 / 내 사이트에 설치하기 | 내 홈페이지 만들기 |
| 자체 제공 | 승인 지식, AI, 상담 링크·위젯, 상담 관리실, 사람 인계, 홍보·매체, 사용량·구독 | 사이트 제작·수정·공개, 서비스 정보, 일반 문의, 예약·달력, 알림·구독 |
| 선택 연결 | Field 등 외부 업무 서비스 | 외부 AI 플랫폼 설치·권한 설정 |
| 단독 동작 | Field 서버·DB·계정·예약·구독 없이 전 과정 이용 | AP 서버·DB·계정·구독 없이 사이트·일반 문의·예약 운영 |
| 장기 확장 | 다양한 외부 서비스의 커넥터와 AI 배포 인프라 | 견적·기사 배정·현장 작업·증빙·청구·사후관리 |

```text
Agent Platform                                Field
자체 계정 / 자체 사업 조직                      자체 계정 / 자체 사업 조직
사업 AI / 승인 지식 / AI 상담 원본              사이트 / 서비스 / 직접 문의 원본 / 예약 원본
자체 구독 / 메시지 / 매체 운영                   자체 구독 / 메시지 / 현장 업무
             └──────── 공식 API·위젯·웹훅 ────────┘
                         동일 계약
              일반 외부 홈페이지 / 제휴 매체 / 다른 연동 앱
```

두 제품이 같은 회사에서 운영되어도 예외 내부 API, 상대 DB 접속, 공통 세션 쿠키, 고객별 수작업 설치를 전제로 하지 않는다. 초기에는 같은 인프라 장비를 활용할 수 있지만 독립 배포와 논리 격리는 유지한다. 같은 장비에서 발생할 공통 장애까지 제거됐다고 주장하지 않는다.

### 1.3 독립성 불변조건 — 구현 중 임의 변경 금지

| ID | 필수 조건 |
|---|---|
| B01 | AP를 배포할 때 Field DB·마이그레이션·환경변수·서버를 요구하지 않는다. |
| B02 | Field를 배포할 때 AP DB·마이그레이션·환경변수·서버를 요구하지 않는다. |
| B03 | AP와 Field는 별도 사용자·조직·membership·로그인 세션·서명키를 가진다. 같은 이메일로 자동 연결하지 않는다. |
| B04 | DB·마이그레이션·런타임 계정·큐·파일 접근권한·암호화 키·백업은 제품별이다. 상대 테이블 JOIN/FK/직접 SQL 금지. |
| B05 | Field 커넥터는 외부 통합자와 같은 정식 API·범위·승인·비용·속도 제한을 사용한다. |
| B06 | 가입·AI 활성화에 사이트·캠페인·매체·예약 설정을 강제하지 않는다. |
| B07 | AI 없이도 Field의 원래 일반 문의·예약·고객 연락은 이용 가능해야 한다. |
| B08 | 전체 상담 원본과 업무 요청 원본의 소유를 분리한다. 같은 대화를 양쪽에서 독립적으로 수정하지 않는다. |
| B09 | 승인 정보의 제품 간 반영은 비동기 계약이다. 공유 DB의 원자적 전환이나 항상 즉시 동일 상태를 약속하지 않는다. |
| B10 | 연결·연결 해제·AI 중지·사이트 비공개·각 제품 해지는 서로 다른 동작이다. |
| B11 | 각 제품은 독립 구독 원장과 별도 출시 게이트를 가진다. 묶음 요금과 공유 크레딧은 이번에 자동 도입하지 않는다. |
| B12 | 기존 고객·사업자/서비스 제공자·매체·관리자 역할을 보존하되 제품별 권한으로 분리한다. |

### 1.4 사이트 제작 AI와 고객 상담 AI를 구분한다

**Field의 ‘사이트를 만들어주는 AI’는 Field 소유의 제작 도구다.** 기존의 템플릿 + AI 제작 결정을 지키기 위해 Field 자체 LLM 어댑터로 페이지 JSON 변경안을 만든다. AP의 고객 상담 런타임을 호출하거나 AP 구독을 요구하지 않는다. LLM 공급사 SDK 같은 무상태 유틸리티 코드는 재사용할 수 있지만 키·사용량·호출·작업 기록은 분리한다.

**고객이 ‘AI에 문의하기’를 누를 때 작동하는 AI는 AP의 외부 설치 기능이다.** Field는 승인된 설치 구성과 공개 위젯만 이용한다. 새 AI를 Field DB에 만들어 고객 상담을 흉내 내지 않는다.

AP가 중단돼도 Field의 제작 AI는 AP 때문에 중단되지 않는다. 공통 LLM 공급사 자체가 장애인 경우에는 별도 외부 의존 장애로 표시하고 Field 템플릿·직접 편집을 유지한다.

### 1.5 기존 21개 결정의 귀속

| 번호 | 유지할 결정 | 제품/검수 귀속 |
|---|---|---|
| 01 | 다양한 1인 업종에 개방 | 두 제품. 전문 업종 업무를 모두 지원한다는 의미는 아님 |
| 02 | 템플릿 + AI 사이트 제작 | Field. AP 가입·사용과 무관 |
| 03 | 일반 문의 + 예약 요청 + 별도 관리실 | Field 자체 완결. AP는 자체 상담실, 예약은 연결했을 때만 |
| 04 | AI 채팅 + 문의 양식 + 예약 양식 | 연결된 Field에서 세 경로 제공. 미연결 Field의 직접 양식은 계속 제공 |
| 05 | 모바일·PC 웹, 네이티브 앱 제외 | 두 제품·매체·각 관리자 화면 |
| 06 | 사업자 카카오톡 + 웹 푸시 | 이벤트 원본 제품이 책임 발송. 중복 발송 금지 |
| 07 | 고객 이름·휴대전화, 회원가입·OTP 없음 | 각 원본 제품의 비회원 접수. 번호를 본인 식별자로 취급하지 않음 |
| 08 | 고객 카카오 실패 시 문자 대체 | 단일 알림 책임 제품에서만 적용 |
| 09 | 직접 처리할 업무만 사장님 외부 알림 | 양쪽 공통. 단순 AI 질의와 매체 노출은 제외 |
| 10 | 허용 구성요소 내 AI 사이트 제작 | Field. 임의 HTML·JS 생성 금지 |
| 11 | 여러 페이지, 한 페이지 완성도 가능 | Field |
| 12 | 기본 주소 + 자체 도메인 | Field 사이트. AP는 자체 공통 상담 도메인·외부 설치; AP 화이트라벨 도메인은 별도 후속 |
| 13 | 구조화 서비스 목록 | Field 원본 또는 AP 직접 입력 원본. 연결 시 출처·버전 매핑 |
| 14 | 희망시간 제출형 + 시간표 선택형 | Field. AP는 연결 기능으로 선택 노출 |
| 15 | 자체 달력 + 수동 일정, 외부 캘린더 제외 | Field. AP 자체 달력은 만들지 않음 |
| 16 | 누구나 가입·개설 | 두 제품 사업자. 위험 기반 제한과 매체 설치 검증은 별도 |
| 17 | 무료 체험 후 명시적 유료 구독 | 각각의 제품. 계정 연결만으로 상대 결제 시작 금지 |
| 18 | 고객의 서비스 대금은 플랫폼 외부 수령 | 두 제품 동일. 예약금·서비스 대금·매체 정산 제외 |
| 19 | 이메일 + 카카오 로그인 | 제품별 앱 설정·동의·세션. 동일 이메일 자동 병합 금지 |
| 20 | 직접 등록·승인한 정보·서비스·FAQ·정책만 AI 참고 | AP 직접 승인 및 Field에서 승인한 정보를 공식 커넥터로 가져와 검수. 임의 크롤링 제외 |
| 21 | 초안 저장 → 검토·공개, 복구 후 재승인 | Field 사이트 / AP 지식·AI·홍보 각각 적용 |

Field에 AP 연결이 없는 상태는 장애도 미완성 계정도 아니다. 단, 전체 연결 상품의 인수 테스트에는 AI 문의 경로가 실제로 설치되는지 검수한다. 독립 Field 출시를 전체 통합 완성으로 보고하지 않는다.

### 1.6 출시 단위

| 릴리스 | 내용 | 기다리지 않아도 되는 것 |
|---|---|---|
| A — AI Core | AP 가입·지식·AI·자체 상담·외부 위젯·알림·구독·운영 | Field 사이트·예약, 홍보 카드·매체 |
| F — Field Core | 사이트 제작·도메인·직접 문의·예약·알림·구독·운영 | AP 설치·매체 |
| I — Field Connector | 정식 연결·권한·지식 동기화·외부 설치·업무 전달·API 답변 | 제휴 매체 광고 기능 |
| D — Distribution | AP 홍보 카드·제휴 매체·승인·집계 | Field. 연결된 예약 전환 지표만 Field 이벤트가 있을 때 표시 |
| Suite | A+F+I+D의 전체 인수 및 제품별 독립 회귀 | 없음. 전체 최종 범위의 완료 판단 |

Firsthand식 대화형 홍보·매체 기능을 삭제하는 것이 아니다. **기본 외부 설치가 매체 기능의 개발을 기다리지 않도록 출시 단위를 분리**한다. AP Core부터 독립적으로 검증하고, Field Core는 병렬 개발하며, 매체는 AP의 확장으로 제공한다.

### 1.7 범위 밖

현재 단계에서 범용 AI 에이전트 마켓, 고객 서버 온프레미스 설치, 임의 도구/MCP 실행, 브라우저 자동 수집, 웹 문서 자동 학습, 이미지 생성·진단, AI 전화, 고객 서비스 대금·예약금 결제, 광고 자동 입찰/거래소, 매체 광고비 정산, 리타게팅·고객 프로필 판매, 다인 기사 배정 UI는 만들지 않는다. 공개 API는 문서화된 설치·상담·제한된 커넥터 계약이며 무제한 외부 실행 권한을 판매하는 제품이 아니다.

---

## 02. Agent Platform 독립 제품 PRD

### 2.1 제품의 완료 정의

**Field 설치 파일·계정·서버·DB가 전혀 없는 환경**에서 사업자가 가입하고 정보를 등록·승인한 뒤, AP 상담 링크 또는 자신이 소유한 외부 사이트에 위젯을 설치하고, 별도 고객 기기의 실제 문의를 받아 사람이 답변하며, 유료 구독·해지·데이터 내보내기까지 진행할 수 있어야 한다.

AP 사업자는 초기에는 조직 1개·대표 AI 1개라는 제안 한도로 시작한다. 추후 다중 AI 확장에 대비해 agent_id를 두되 초기 UI에서 불필요한 에이전트 편성을 요구하지 않는다. 서비스·제품 안내는 지원하지만 재고·주문·배송·결제의 실시간 자동 처리를 연결 없이 제공하지 않는다.

### 2.2 필수 사용 흐름

| 순서 | 화면과 행동 | 저장·검증 |
|---|---|---|
| 1 | AP 홈페이지 → 내 사업 AI 만들기 | Field 가입 링크로 강제 이동 금지 |
| 2 | 이메일 또는 카카오 가입 | AP 자체 사용자·조직·세션·체험 생성 |
| 3 | 상호·소개·서비스·지역·영업시간·FAQ 등록 | 초안, 입력 출처, 미확인 정보. 사이트·예약 설정 불필요 |
| 4 | AI 이름·말투·안내 범위·사람 연결 설정 | AgentDraft, 조직 권한 |
| 5 | 답변 테스트 | 근거·미등록 질문·인계 확인; 실제 고객 알림/리드 생성 금지 |
| 6 | 검토 후 활성화 | KnowledgeRelease와 AgentRelease의 AP 내부 검증 |
| 7 | 상담 링크 공유 또는 외부 설치 | 운영 주소·허용 도메인·상태 확인 |
| 8 | 고객 상담 → 이름·번호로 문의 제출 | AP의 원본 대화/비회원 접근 권한 |
| 9 | AP 문의함에서 사람 응대 | AI 중지·답변·알림·고객 복귀 |
| 10 | 필요하면 외부 서비스 연결 | 선택 기능. 연결 전에도 1~9 정상 운영 |

최초 고객 문의 전에는 문의 0건을 그대로 표시한다. 예시 고객·허위 후기·가짜 정확도·매출 그래프를 채우지 않는다. 사이트가 없어도 상호와 서비스 소개가 있는 독립 상담 랜딩 화면을 제공한다.

### 2.3 AI가 사용하는 데이터

지식 원본은 AP 직접 입력 또는 승인된 외부 커넥터의 구조화 데이터다. `source_kind=native|connector`, `source_id`, `external_entity_id`, `source_revision`, `content_hash`, `approved_by`, `approved_at`를 보관한다.

Field 연결 후 해당 서비스의 가격·운영시간은 Field 원본을 참조한다. AP 화면에서는 ‘Field에서 관리’로 표시하고 같은 필드를 직접 수정하지 못하게 한다. AP 고유 FAQ와 말투는 AP에서 편집할 수 있다. 직접 입력 데이터와 연결 데이터가 같은 대상을 설명하면 출처 매핑·우선순위를 확인한 후 연결하며 자동 덮어쓰기·단순 이름 일치 병합을 하지 않는다.

| 객체 | 역할 |
|---|---|
| KnowledgeDraft | 비공개 입력·수정·가져온 변경안 |
| KnowledgeRelease | 승인된 불변 지식 묶음; 사이트 ID 불필요 |
| KnowledgeSource | 외부 연결·마지막 검증 시각·승인된 소스 버전·동기화 상태 |
| AgentRelease | 말투·허용 기능·안내 문구·정책 버전 |
| Deployment | 자체 링크·소유 사이트 위젯·제휴 카드 등 설치 위치 |
| Conversation / Submission | 고객 대화와 최종 제출된 연락 요청 |
| ActionRequest | 고객이 확인한 외부 업무 전달 요청. 예약 원본이 아님 |

가격·예약 가능성은 추측하지 않는다. Field 연결 데이터가 최신 승인 상태인지 확인할 수 없으면 해당 조건의 확정적 안내와 예약 도구를 중단하고 사람 문의로 전환한다. 세부 최신성·승인 규칙은 연동 계약 4.5절을 따른다.

### 2.4 기본 AI와 도구

| 기능 | 기본 AP 단독 | 외부 연결 시 |
|---|---|---|
| 상호·서비스·FAQ 안내 | 승인 AP 정보 조회 | 승인된 연결 데이터도 출처 검증 후 이용 |
| 문의 초안 | 고객 발언·선택 서비스 정리 | 동일 |
| 정식 접수 | 고객의 제출 버튼과 서버 검증 후 AP 저장 | 동일 |
| 사람 인계 | AP 문의함으로 전환 | 허용받은 Field 관리실에도 API로 표시 |
| 예약 시간 조회 | 기능 비노출 | 활성 커넥터의 제한 API로 조회 |
| 예약 요청 전달 | 기능 비노출 | 고객 확인 후 ActionRequest → Field 요청 |
| 예약 확정·가격 변경·할인·결제 | 금지 | 연결되어도 금지 |

LLM은 tenant·권한·금액·발신자를 결정하지 않는다. 서버가 고정한 agent/조직/지식 버전으로 검증된 도구만 호출한다. 고객 메시지나 외부 기사 내용이 공식 지식·정책·새 도구가 되어서는 안 된다. 임의 URL fetch·SQL·shell·외부 메일 보내기는 도구에 없다.

답변은 답변문, 사용 근거 ID, 지식 버전, 미확인 항목, 사람 인계 제안으로 구조화한다. 모델의 비공개 사고과정은 저장하지 않는다. 이름·번호·상세 주소는 모델 입력에서 최소화하며 고객 사진은 초기 비전 분석으로 보내지 않는다.

### 2.5 설치 상품 — 기본 위젯과 광고 카드를 분리

#### 기본 설치: AP Core 필수

AP 대표 상담 링크, QR, 웹사이트용 버튼·플로팅 위젯·인라인 대화 중 검수된 기본 렌더러를 제공한다. 초기 프리셋은 한 엔진의 `floating`과 `inline` 두 표시 모드로 충분하다. 고객이 준비할 것은 직접 도메인 소유/설치 권한을 확인하고 발급된 설치 코드를 넣는 일이다.

Field도 동일 코드 로더·공개 배포 ID·허용 도메인 검증을 사용한다. Field에만 AP 서버의 내장 컴포넌트를 직접 import하거나 비밀키로 우회하는 경로는 없다. 로더 실패 시 원래 Field 문의·전화·예약 버튼은 남는다.

```html
<!-- 예시 계약. 실제 운영 host와 검증된 public deployment ID로 발급할 것. -->
<script async src="https://embed.agent-platform.example/sdk/v1.js"
        data-deployment="dep_public_example"
        data-mode="floating"></script>
```

`.example`은 실제 배포 주소가 아니다. 스크립트에는 운영자 API 토큰을 넣지 않는다. 위젯은 API용 단기·대화 범위 세션을 발급받고 원본 사이트의 고객 데이터나 DOM 전체를 수집하지 않는다. 테마·크기·대표 질문만 제한된 옵션으로 받는다.

자기 사이트의 고객지원 위젯은 광고 캠페인 생성을 요구하지 않는다. 모든 접점은 사업자명과 AI 안내를 표시한다. **‘광고’ 표시는 유료/스폰서 콘텐츠의 홍보 카드에 필수**이며, 일반 고객지원 위젯을 광고상품으로 강제 분류하지 않는다.

#### 제휴 매체 배포: Distribution 릴리스

홍보 카드의 초안·공개·중지, 매체 도메인·광고 위치, 사업자의 배치 요청, 매체의 정확한 카드 버전 승인, 외부 대화→AP 안전 접수, 집계 성과를 제공한다. Firsthand의 모든 광고 네트워크 기능을 재현한다고 표현하지 않는다.

카드의 가격은 승인 서비스에 바인딩한다. campaign release 변경 시 새 버전 승인이 필요하며, 기존 승인을 최신 버전으로 바꿔치기하지 않는다. 위험한 사실 변경은 관련 노출을 보류한다. 부모 매체에 이름·번호·사진·대화·세션 비밀값을 반환하지 않는다.

### 2.6 외부 대화와 비회원 접수

외부 iframe에서는 일반 안내와 서비스 선택을 한다. 연락처·사진·상세 주소를 받는 양식은 AP의 1차 상담 도메인에서 제공한다. 고객이 외부 채팅에 식별정보를 직접 입력할 가능성도 고려해 마스킹과 보존을 적용한다. 개인정보가 전혀 들어오지 않는다고 가정하지 않는다.

전환은 단기·1회·대상 바인딩된 handoff 권한으로 처리한다. 제3자 쿠키가 없다는 이유로 실패하거나 로그인부터 요구하지 않는다. 브라우저의 외부 쿠키 제약을 고려한 설계다.[S05]

기존과 같이 회원가입·휴대전화 OTP 없이 이름·번호로 접수한다. 번호는 미인증으로 표시한다. 최초 접수 브라우저의 대화 범위 HttpOnly/Secure 세션과 별도 접수 확인키를 사용하고, 알림 링크/번호만으로 원문·사진·과거 기록을 공개하지 않는다. 확인키는 문자·알림톡에 포함하지 않는다. 다른 브라우저에서 확인키가 필요할 수 있는 불편과 번호 오입력의 잔여 위험을 명시한다.

같은 대화에서 AI→사람 문의→외부 업무 요청으로 넘어갈 때 원문과 선택 정보를 보존한다. 외부 업무 전송에는 수신 사업자·외부 제품·전달 필드·요청 상태·필요 처리 안내를 보여주고 명시적 제출을 받는다. 자동으로 Field 가입 계정이나 고객 프로필을 만드는 것은 금지한다.

### 2.7 상담 원본과 사람 응대

AP에서 시작한 대화 원본은 AP DB에만 있다. AP 관리실에서 열든 Field가 정식 API로 보여주든 같은 conversation_id와 message sequence를 사용한다. Field UI에서 작성한 답변도 AP 서버가 저장·모드 전환·알림 생성까지 담당한다.

`ai_assisting → needs_owner → human_active → waiting_customer → closed`를 기본 상태로 한다. 고객이 추가 답변하면 다시 needs_owner로 연다. spam 상태는 대화·증빙 보존정책과 별도로 발송을 중단한다. 사람 응대 진입과 답변 저장을 원자적으로 처리하고, 생성 중인 AI는 마지막 전송 전에 automation_paused와 revision을 다시 검사한다.

원문, 요약, 미확인 값, 고객 공개 답변, 내부 메모를 분리한다. 내부 메모는 외부 매체와 고객 응답 스키마에서 제외한다. AP 장애 시 Field가 AP 답변을 성공으로 표시해서는 안 된다. 로컬 입력은 전송되지 않은 초안으로 남기고 복구/재전송 선택을 제공한다.

### 2.8 AP 알림·사용량·구독

단독 AP는 자체 카카오톡·웹 푸시 사업자 알림과 고객 카카오→실패 문자 대체를 가진다. Field의 메시지 Worker가 없어도 동작해야 한다. 두 제품이 같은 공급사를 쓰더라도 발송 주체·계약 적합성·템플릿·사용량 원장은 구분한다. AP 업무 알림은 직접 접수·미해결 인계·고객 추가 답변에 한하며 단순 질문에는 보내지 않는다.

AP 구독으로 AI 응답·상담실·기본 외부 설치를 사용할 수 있다. 예약·사이트 기능을 구매해야만 AP 결제를 진행할 수 있으면 실패다. 기본 상담 설치는 매체 요금제와 분리한다. 체험 14일, 대표 AI 1개, 유료 월 500회 AI 응답 등은 운영비 검증 전 제안값이다. **독립 AP 가격은 새 plan version으로 정하고, 기존 Field 통합안의 29,000원을 자동 적용하지 않는다.**

원가·동의가 확정되지 않은 플랜은 test mode에서만 결제한다. production은 승인된 가격·세금·갱신·해지 조건 없이는 유료 판매를 활성화하지 않는다. 이는 추가 사용자 설문이 아니라 출시 가격 확정 작업이다.

AP 해지 시 신규 AI·신규 접수·새 캠페인을 제한해도 기존 상담의 정리·내보내기 경로를 유지한다. Field 구독은 해지되지 않는다. 이미 Field에 접수된 예약은 Field에서 계속 처리하며, AP를 다시 구독해야 예약을 볼 수 있게 만들지 않는다.

### 2.9 역할별 화면

| ID | 역할/화면 | 핵심 요소 |
|---|---|---|
| AP-P01 | AP 제품 홈 | AI 만들기·외부 설치·요금·매체·로그인 |
| AP-O01 | 가입·빈 관리실 | 이메일/카카오, 시작/이어서 하기, 데모 분리 |
| AP-O02 | 사업 정보·지식 | native/connector 출처, 초안/승인, 가져온 변경 검토 |
| AP-O03 | AI 설정·테스트 | 이름·말투·허용 도구, 근거·상태·실제 활성화 |
| AP-O04 | 문의함·대화 | 직접 답변·사람 인계·미인증 번호·알림 실패 |
| AP-O05 | 공유·설치 | 링크·QR·소유 도메인·설치 코드·테스트·중지 |
| AP-O06 | 연동 앱 | 권한·출처·Field 연결·재동의·해제·실패 |
| AP-O07 | 홍보 카드 | 초안·미리보기·공개·버전·배치 |
| AP-O08 | 성과·사용량 | 대화/접수/외부 전환 구분, 실제 수금은 아님 |
| AP-O09 | 구독·계정·데이터 | 별도 요금/동의/해지·export·삭제 |
| AP-C01 | 고객 상담 랜딩/위젯 | 상호·AI 고지·공개 안내·사람 문의 |
| AP-C02 | 안전 접수/후속 대화 | 이름·번호·사진·확인키·외부 요청 상태 |
| AP-M01~05 | 제휴 매체 | 운영·위치·배치 검토·집계·도메인/설정 |
| AP-A01~06 | AP 관리자 | 운영·조직·발송·AI/배포·구독·신고/감사 |

매체는 자기 도메인/위치/카드 승인과 집계만 본다. 사업자와 매체 역할을 같은 사람에게 허용하더라도 별도 membership으로 확인한다. AP 관리자라는 이유로 Field DB나 예약 관리자 권한을 주지 않는다.

### 2.10 AP 원본 데이터와 내부 API

AP 전용 DB: `ap_users`, `ap_identities`, `ap_organizations`, `ap_memberships`, `ap_knowledge_sources`, `ap_knowledge_drafts`, `ap_knowledge_releases`, `ap_agents`, `ap_agent_releases`, `ap_deployments`, `ap_conversations`, `ap_messages`, `ap_submissions`, `ap_visitor_grants`, `ap_action_requests`, `ap_connector_bindings`, `ap_campaigns`, `ap_campaign_releases`, `ap_publishers`, `ap_slots`, `ap_placement_approvals`, `ap_events`, `ap_outbox`, `ap_notifications`, `ap_usage`, `ap_subscriptions`, `ap_invoices`, `ap_audit`.

표의 `ap_`는 소유권을 명확히 하기 위한 명세 접두어이며 DB가 제품별로 나뉘면 실제 테이블 접두어는 ADR로 생략 가능하다. Field 외부 ID는 string 메타데이터이며 AP의 FK가 아니다.

| 계약 | 핵심 동작 |
|---|---|
| POST /v1/organizations | AP 조직·체험 생성 |
| PATCH /v1/knowledge/draft | revision 조건 수정, source 필드 통제 |
| POST /v1/knowledge/releases | 사업자 승인 버전 생성 |
| POST /v1/agents / POST /v1/agents/{id}/activate | 사이트·예약 없이 개설·활성화 |
| POST /v1/agents/{id}/tests | 테스트 격리, 근거 반환 |
| POST /v1/deployments | link/owned_embed/partner 구분, 권한·허용 origin |
| POST /v1/public/deployments/{id}/sessions | 짧은 공개 대화 세션, 관리자 토큰 금지 |
| POST /v1/engagements/{id}/messages | 승인 정보·모드·비용 검사 |
| POST /v1/engagements/{id}/handoffs | AP 1차 접수 권한 교환 |
| POST /v1/conversations/{id}/submissions | 최종 제출, 비회원 capability |
| GET/POST /v1/conversations/{id}/messages | 권한/actor 구분, human reply와 AI 실행 분리 |
| POST /v1/action-requests | 고객이 확인한 외부 작업 요청 저장 |
| POST /v1/subscription/checkout / cancel | AP 구독만 처리 |

내부 API와 위임 공개 API의 이름이 비슷해도 인증 주체·스코프·응답 허용 필드를 분리한다. 교차 제품 호출에는 연동 계약의 전용 경로를 사용한다.

---

## 03. Field 독립 제품 PRD

### 3.1 Field의 책임

Field는 사업자 스스로 사이트를 개설하고 고객의 직접 문의와 예약을 운영하는 제품이다. AP는 선택적으로 설치하는 외부 서비스다. Field 홈페이지·일반 문의·예약·구독의 요청 경로에서 AP가 상시 필수 호출이 되어서는 안 된다.

Field 자체 사이트 제작 AI는 Field의 제작 기능으로 유지한다. 상담용 AI 설치와 제작용 LLM 호출은 비용·권한·상태를 명확히 구분한다. 관리실의 ‘AI 연결’은 AP 계정·AI·권한을 연결하는 화면이지 AP 전체 관리 콘솔의 복제본이 아니다.

### 3.2 기존 5단계 셀프 사이트 제작

**플랫폼 홈 → 가입 → 빈 시작 화면 → 사업 정보 → 디자인 → 편집 → 연락·예약 → 확인·공개 → 운영실 오늘**.

| 단계 | 필수 동작 |
|---|---|
| 사업 정보 | 상호·업종·서비스·지역·소개·운영시간·연락처·사진 입력; 서버 초안 |
| 디자인 | 템플릿 또는 AI 설명; 입력한 실제 상호·서비스로 생성 |
| 편집 | 글·사진·alt·색·허용 폰트·페이지·섹션 순서·직접/AI 수정 |
| 연락·예약 | 사이트 직접 문의, 전화, 두 예약 방식, 사업자 카카오/푸시 설정; AP 연결은 선택 |
| 확인·공개 | 기본 주소, 모바일, 필수 정보, 미승인 변경 확인; 실제 공개 후 성공 표시 |

AP 연결 전에도 사이트를 공개할 수 있다. 설치를 권하는 카드에 ‘나중에 연결’ 경로를 두며 AI 상담이 없는 상태의 버튼은 ‘문의 남기기’로 명확히 표시한다. 비연결 상태에서 AI가 답하고 있다고 표시하지 않는다.

Essential·Editorial·Warm 3개 배치는 색상만 바뀌는 동일 레이아웃이 아니다. 한 페이지 기본 사이트와 서비스·소개·작업 사례·FAQ 등 최대 5개 소개 페이지 시작안을 유지한다. 시스템 문의·예약 화면은 소개 페이지 수와 별도다. 사진 없는 사업자도 개설할 수 있다. 이미지 생성·외부 이미지 자동 수집은 제외한다.

### 3.3 편집·저장·공개·복구

`FieldBusinessDraft/FieldCatalogRelease`와 `SiteDraft/SiteRelease`는 Field 내부 객체다. 초안은 서버에 자동 저장하고 base_revision 충돌을 검사한다. 약 1초 저장 디바운스는 제안값이다. 오프라인/실패 중에는 저장 완료라고 표시하지 않는다.

AI 생성 작업은 queued/running/proposed/applied_to_draft/failed/canceled/stale를 구분한다. 실제 LLM 결과를 제한된 페이지 JSON으로 검증한 뒤 초안만 수정한다. 생성 중 직접 수정하면 오래된 AI 결과를 자동 덮어쓰지 않는다. 실패·취소·재시도에 입력과 사진을 잃지 않는다.

Field 내부에서 승인한 사업정보·사이트 공개는 해당 DB 트랜잭션/작업 상태로 일관성 있게 적용한다. **AP로의 동기화 성공까지 Field 공개 트랜잭션에 넣지 않는다.** 성공 후 outbox로 승인 정보 변경을 발행하고 별도 ‘AI 정보 동기화 대기/검토 필요’ 상태를 보인다.

과거 디자인 복구는 초안으로 가져오고 재승인 후 공개한다. 현재 서비스 가격·예약 조건·확정 예약은 디자인 복구로 되돌리지 않는다. 사실 복구가 필요하면 별도 변경 승인이다. AP AI/배포 중지는 사이트 디자인 복구로 해제되지 않는다.

### 3.4 도메인·공개 자산

기본 슬러그와 자체 도메인 기능은 유지한다. 자체 도메인은 등록·소유 증명·DNS·TLS·연결·대표 URL을 구분하며, 실패 시 기본 주소를 유지한다. 도메인 구매·갱신 판매는 제외한다.

AP 위젯을 Field 자체 도메인에 붙일 때도 새 origin 승인이 필요하다. Field의 도메인 검증 사실을 숨은 DB로 전달하지 않고, 공식 커넥터의 signed source/공개 검증 엔드포인트 또는 AP가 지원하는 일반 소유 검증으로 확인한다. 기본 플랫폼 호스트는 정확한 사업자 서브도메인 단위로 제한한다. 전체 플랫폼 `*` 허용으로 다른 사업자가 설치키를 재사용하게 하지 않는다.

사이트 공개 사진과 비공개 문의 첨부는 저장 정책을 분리한다. HEIC 등은 안전한 변환, 실제 파일 형식 검사·용량·EXIF 제거를 거친다. 공개 릴리스가 참조하는 사진은 초안에서 삭제했다고 즉시 제거하지 않는다.

### 3.5 AP 연결 화면

Field 메뉴: **더보기 → 연동 서비스 → AI 상담 연결**. 이미 고객 사이트가 공개돼 있든 개설 중이든 별도 설정할 수 있다.

```text
AI 상담 연결
제공 서비스: Agent Platform (별도 서비스)
[기존 계정 연결] [AI 서비스에 가입]

공유할 정보: 승인된 사업 소개·서비스·가격·FAQ
설치할 위치: 이 Field 사이트의 검증된 주소
선택 권한: Field 문의 전달 / 예약 시간 조회·요청 / 대화 조회·답변
요금: Field 이용료와 AP 이용료는 별도. 연결만으로 결제하지 않음.
```

권한·기관·연결 조직·AI를 명확히 표시한다. 허용하지 않은 기능은 숨기거나 권한이 필요하다는 이유를 표시한다. 연결 실패/일부 동의/검토 필요/정보 오래됨/중지/만료를 ‘연결됨’ 하나로 뭉개지 않는다.

AI 위젯은 AP 공식 SDK로 설치한다. 설정 화면에는 연결 상태·마지막 동기화·AI 테스트·AP 관리실 열기·연결 해제를 둔다. AP의 홍보·매체·전체 구독 메뉴를 Field 내부 소유 기능처럼 복제하지 않는다.

### 3.6 Field 자체 문의와 연결된 AI 문의

| 구분 | Field 자체 직접 문의 | AP에서 시작한 AI 문의 |
|---|---|---|
| 대화 원본 | Field | AP |
| 고객 후속 대화 | Field 상담 도메인 | AP 상담 도메인 |
| 관리실 표시 | Field DB에서 조회 | 위임 API 조회; 요약 인덱스와 업무 링크만 Field에 저장 |
| 사람이 답변할 때 | Field 메시지 저장·알림 | Field BFF → AP 위임 답변 API → AP 저장·알림 |
| AP 장애·연결 해제 | 정상 이용 | 원문 재조회/전송 불가 표시; 이미 접수된 Field 업무는 유지 |
| 예약 원본 | Field | 연결 요청이 수락되면 Field |

사업자에게는 문의 목록을 한 화면에서 보여줄 수 있지만 행마다 `Field 직접 문의`/`외부 AI 상담` 출처를 표시한다. 연결 조회 장애를 전체 문의 0건으로 표시하지 않는다. AP 문의를 보기 위해 Field 전체 관리 권한을 AP에 넘기거나 AP의 모든 채널 대화를 Field에 노출하지 않는다. 기본 범위는 **이 연결/배포/외부 업무에 관련된 AP 대화만**이다.

Field는 AP 대화의 전체 원문을 상시 복제하지 않는다. 업무 수행에 필요한 연락처·고객 제출 요약·서비스·희망일·승인한 첨부는 고객 확인 후 받은 작업 스냅샷으로 보관한다. AP 대화 원본과 별개로 그 수신 시각·목적·출처·보존기간을 기록한다. 요약 미러의 최신 시각과 상태도 표시한다.

AP 연결이 해제되면 그 원문/답변 권한은 사라진다. 기존 Field 업무 처리·달력·제출된 연락 정보는 정당한 보존 범위에서 남는다. 원래 대화를 무단으로 복제해 연결 해제를 우회하지 않는다.

### 3.7 예약·달력의 원본

기존 희망시간 제출형과 시간표 선택형을 모두 제공한다. 각 서비스는 기본 방식을 상속하거나 선택할 수 있으며 사이트 생성 과정이 서비스별 선택을 덮어쓰지 않는다.

시간표는 사업자 1명의 공통 자원, 소요·준비·이동시간, 영업시간·휴무·예외일, 최소 요청 여유와 기간을 적용한다. 모든 서비스가 같은 자원을 공유한다. 미확정 요청은 슬롯을 독점하지 않고, 확정·수동 차단만 점유한다. 동시에 들어온 요청은 승인 시 DB에서 최종 충돌을 검사한다.

| 상태 | 점유 | 처리 |
|---|---|---|
| requested | 없음 | 확정/시간 제안/거절/고객 철회 |
| proposed / customer_accepted | 없음 | 새 조건에 대한 고객 동의, 사업자의 최종 승인 |
| confirmed | 있음 | 완료·변경 요청·취소 요청 |
| change_requested / cancel_requested | 기존 점유 유지 | 새 합의와 승인 후 교체/해제 |
| completed / canceled / rejected / expired | 과거 기록 | 결과 표시; 임의 자동 노쇼 처리 금지 |

AP는 예약 가능 시간을 읽고 요청을 만들 수 있으나 confirm 권한이 없다. Field 사용자의 명시적 승인만 일정 확정 API를 실행한다. 제안을 고객이 수락해도 자동 확정되지 않는다.

`[start-before_buffer, end+after_buffer)` 범위에 같은 resource의 겹침을 차단하고 예약 상태·점유·outbox를 한 Field DB 트랜잭션에 저장한다. 수동 일정도 예외가 아니다. 시간 변경 때 기존 점유를 먼저 삭제한 뒤 실패하는 상태를 만들지 않는다. 과거 가격·소요시간은 접수/확정 당시 스냅샷을 유지한다. 시간은 timezone 포함, 표시 기본은 Asia/Seoul이다.

### 3.8 알림·구독·장애

Field 직접 문의·예약 알림은 Field가 발송한다. AP에서 시작한 연결 대화의 고객 알림은 정상 연결 중 AP가 발송하며, Field는 해당 사건을 이벤트로 전달한다. 이미 발송된 같은 사건을 두 제품이 각각 카카오/문자로 보내지 않는다. 상세 규칙은 연동 계약 4.8절을 따른다.

Field의 유료 이용은 사이트·직접 문의·예약·도메인·자체 알림을 기준으로 독립 제공한다. 과거 통합 가격 29,000원+부가세는 최종 가격이 아니며 분리 후 구성 변경에 맞춰 재확정한다. AP를 구독하지 않아도 Field 결제가 가능해야 한다. 연결 동의는 별도 제품 결제 동의가 아니다.

해지 시 이미 확정된 미래 예약과 종결 중인 업무의 정리/내보내기 경로를 유지한다. 일반 정리 30일, 예약은 마지막 예정일+7일 등 기존 제안값은 법무·운영비 검수 후 확정한다. Field를 해지해도 AP 계정·독립 AI·다른 사이트 설치를 자동 해지하지 않는다.

AP 장애 시 고객에게 Field 직접 문의/예약과 전화 경로를 제공하되, AP의 기존 미전송 내용을 몰래 복사해 새 문의를 만들지 않는다. 고객이 새 요청을 제출하면 `fallback_origin`과 관계를 기록하고 가능한 요청 ID로 중복 후보를 보여준다. 같은 전화번호만으로 두 대화를 자동 병합하지 않는다.

### 3.9 역할별 화면 유지

| ID | 화면 | 변경점 |
|---|---|---|
| F-P01 | Field 홈 | 홈페이지·사업 운영 중심. AI는 외부 서비스 연결로 소개 |
| F-O01~07 | 가입·빈 시작·5단계·개설 완료 | 기존 셀프 제작 보존; AP 연결은 선택 |
| F-O08 | 오늘 | 직접 문의·외부 AI 업무 구분, 예약·알림 실패 |
| F-O09 | 문의함·상세 | 출처·전송 가능 상태·대화 원본·직접 답변 |
| F-O10 | 예약·달력 | 두 방식·수동 일정·변경·취소·충돌 |
| F-O11 | 내 사이트 | 편집·미리보기·공개·복구 |
| F-O12 | 서비스·FAQ·운영 규칙 | Field 원본, AP 동기화 상태 |
| F-O13 | 연동 서비스 | AP 연결·정보 범위·권한·상태·해제 |
| F-O14~16 | 주소·알림·구독/계정 | Field 자체 원장·도메인·설정 |
| F-C01~04 | 고객 사이트·서비스·소개·문의 | 직접 경로 항상 유지; AP 위젯은 설치 상태일 때만 |
| F-C05~08 | 예약·접수 완료·후속 대화·접근 확인 | 직접 접수 원본은 Field; AP 출처는 AP로 안전 연결 |
| F-A01~06 | Field 관리자 | 운영·사업체·제작/도메인·발송·구독·신고/감사 |

모바일은 오늘/문의/예약/내 사이트/더보기 유지. 매체 관리실은 Field 메뉴에서 제거하는 것이 아니라 AP 제품으로 소유권을 옮긴다. 필요하면 AP로 이동 링크를 제공하되 Field 관리자 세션으로 자동 열람하지 않는다.

### 3.10 Field 데이터·API

Field DB: 사용자·조직·사이트·서비스·카탈로그 릴리스·공개 미디어·직접 대화·접수·예약·점유·알림·구독·감사. 연결 데이터는 `field_integrations`, `external_work_requests`, `external_thread_refs`, `source_mappings`, `inbox_events`, `outbox_events`, `revocation_jobs`로 분리한다. AP PK는 문자열 참조이며 cross-DB FK가 아니다.

Field 자체 API는 기존 사이트/문의/예약 경로를 보존한다. 외부에 제공할 `facts`, `capabilities`, `availability`, `external-requests`, `external-request-status`는 별도 integration API로 만들고 요청마다 조직·연결·허용 도구·리소스·현재 상태를 검증한다. AP 토큰만으로 Field 사용자 세션이나 예약 확정 권한을 대신하지 못한다.

---

## 04. 공식 연동 계약 — AP ↔ Field

**이 장은 두 제품 개발 에이전트가 먼저 고정할 네트워크 계약이다.** 실제 서버용 OpenAPI와 인증 공급사 설정은 구현 작업 C01/I00에서 이 규칙으로 생성·검증한다. 경로·필드는 계약 설계이며 현재 호출 가능한 서비스 주소가 아니다.

### 4.1 원본과 복제의 경계

| 데이터 | 원본 | 상대가 보관해도 되는 것 |
|---|---|---|
| Field 가입자·사업체·권한 | Field | 명시적으로 연결한 외부 식별자·권한 범위 |
| AP 가입자·사업체·권한 | AP | 명시적으로 연결한 외부 식별자·권한 범위 |
| Field 서비스·가격·운영시간 | Field | 승인·버전·출처가 있는 지식 스냅샷 |
| AP 직접 등록 FAQ·AI 설정 | AP | 권한 있는 설정 조회 결과; Field 원본으로 자동 덮어쓰기 금지 |
| Field 직접 대화·사진 | Field | 원칙적으로 AP 전달 안 함; 사용자가 별도 전달한 업무만 |
| AP 대화·후속 답변·사진 원본 | AP | Field 통합 문의함의 최소 인덱스, 고객이 전달한 업무 스냅샷 |
| 외부 업무 전달 요청 | AP의 ActionRequest | Field가 접수한 external_request와 수신 증빙 |
| 실제 예약·시간 점유 | Field | AP의 상태 미러·외부 요청 ID·합의 조건 |
| 알림·청구·비용 | 발송/판매 책임 제품 | 상관 ID·결과 메타데이터. 잔액 공유 금지 |
| 매체·배치·홍보 집계 | AP | Field 업무에 필요한 유입 라벨, AP 매체에 별도 승인 집계 |

‘원본은 하나’는 모든 개인정보를 한 제품에 모으라는 뜻이 아니다. AP에서 고객이 Field에 전달하기로 확인한 연락처·요약·첨부는 Field 업무 수행 목적의 **수신 기록**으로 남을 수 있다. 그 데이터와 AP 대화 원본의 보존·정정·삭제 책임은 각각 관리한다.

### 4.2 연결 관계와 식별

초기 연결은 하나의 AP 조직·대표 AI와 하나의 Field 사업체를 명시적으로 매핑한다. AP AI는 다른 일반 웹사이트·공유 링크에도 설치할 수 있다. 다중 Field 사업체에 한 AI를 동시에 매핑해 가격/예약을 섞는 기능은 후속이다.

```text
IntegrationBinding
  connection_id                # 두 서버가 합의한 공개 연동 식별자; 인증 비밀값 아님
  provider_client_id           # 검증된 커넥터 앱
  ap_org_id / ap_agent_id       # AP 자체 ID
  external_org_id              # Field 조직 ID, AP에서는 불투명 참조
  allowed_deployment_ids       # 이 연결의 사이트/배포
  approved_scopes_by_direction
  authorizing_subjects         # 각 제품의 동의한 사용자
  consent_versions / grant_ids
  source_mappings / capabilities
  revision / revoked_at / status
```

상호명·이메일·전화번호로 자동 매핑하지 않는다. API body의 tenant_id, agent_id, 외부 조직 ID는 토큰 바인딩을 바꾸는 권한이 아니다. ID가 유효하더라도 연결 범위 밖이면 거부한다. 새 Field 조직 연결·AI 교체는 새 동의와 변경 영향 검토를 거친다. 기존 요청 ID와 과거 귀속은 유지한다.

### 4.3 두 방향의 권한을 따로 승인

**Field가 AP API를 호출하는 권한과 AP가 Field 업무 API를 호출하는 권한은 다르다.** 동일 토큰을 양쪽 서버에서 받아주지 않는다. 제품 로그인과 OAuth 설치 승인은 별개다.

시작안은 양쪽 제품의 검수된 OAuth 2.0 인가 서버를 사용하는 Authorization Code + PKCE(S256)다. 웹 BFF가 비밀 자격·refresh token을 보관하고 브라우저/설치 코드/localStorage에 넣지 않는다. exact redirect URI, 요청별 state·issuer 검사, 최소 scope, 짧은 access token, refresh rotation을 적용한다. 표준 동작은 검수된 서버/라이브러리로 구현하며 임의 token endpoint를 즉석 작성하지 않는다.[S01]

#### 단계별 연결

1. Field 소유자가 연결 시작. Field 세션·조직·최근 인증 상태를 확인하고 연결 transaction/nonce 생성.
2. AP 공식 인가 화면에서 AP 로그인 또는 가입, 연결할 조직·AI 선택, Field가 요청하는 AP 권한 승인.
3. Field BFF가 code를 교환하고 AP issuer·audience·subject·조직 범위를 확인. 이때 기본 AI 설치만 활성화할 수 있다.
4. Field 정보를 가져오거나 예약을 연결하려면 AP가 별도 등록된 client로 Field 인가 화면을 연다. 사업자가 **Field 데이터 읽기·요청 전달 권한**을 별도로 승인.
5. 양쪽 서버가 연결 transaction과 선택된 조직·grant를 검증한 뒤 기능별 active 상태를 합의한다. 둘째 승인이 취소되면 설치만 유지하고 Field 정보/예약 도구는 비활성.
6. 승인된 정보 동기화·서비스 매핑·AI 테스트 후 위젯 활성화. 무료 체험/구독 조건은 별도 표시하며 연결 승인으로 자동 결제하지 않음.

단계 2·4는 하나의 안내 마법사로 연결할 수 있지만 서로의 동의를 몰래 생략하지 않는다. 이메일/카카오 로그인은 각 인가 화면의 인증 수단일 뿐 다른 제품에 자동 로그인하는 공통 쿠키가 아니다.

#### AP 발급 → Field 보관 토큰의 범위

| Scope | 허용 | 추가 경계 |
|---|---|---|
| ap.agent.read | 선택한 AI의 공개·상태 정보 | AP 전체 조직 조회 불가 |
| ap.sources.refresh | 이 연결의 승인 정보 갱신 요청 | 임의 source/지식 공개 금지 |
| ap.deployments.manage | 검증된 Field 사이트의 배포 생성·중지 | 다른 외부 사이트 배포 삭제 불가 |
| ap.conversations.read | 이 연결·배포 또는 넘겨받은 업무에 관련된 대화 | AI의 다른 사이트 대화를 전부 조회하지 않음 |
| ap.conversations.reply | 연결 대화에 동의한 사업자의 직접 답변 | 설치용 백그라운드 credential에는 넣지 않음 |
| ap.events.read | 이 연결 사건·실패 메타데이터 | 매체/타 연결 이벤트 조회 불가 |
| ap.connection.revoke | 이 연결 해제 | AI 전체 삭제·계정 해지 불가 |

사람 답변에는 최근 유효한 **그 사람의 AP 위임 토큰**을 사용한다. Field membership만 존재하는 다른 직원에게 소유자의 AP 토큰을 대리 사용하지 않는다. 초기 소유자 1명 기준이며 후속 직원은 각자 AP membership·권한 연결이 필요하다. 백그라운드 동기화·배포·수신 이벤트용 installation grant는 사람 답변 scope와 분리한다.

#### Field 발급 → AP 보관 토큰의 범위

| Scope | 허용 | 금지 |
|---|---|---|
| field.facts.read | 승인된 사업 정보·서비스·가격·FAQ | 사이트 초안·내부 메모·전체 고객 목록 |
| field.availability.read | 서비스별 요청 가능 구간 | 예약자 신원·점유 사유 |
| field.requests.create | 고객이 확인한 문의/예약 요청 생성 | 실제 예약 확정·가격 변경 |
| field.requests.read | 이 연결에서 생성한 작업/제안/결과 | 다른 경로 요청 열람 |
| field.proposals.respond | 고객이 특정 제안에 직접 동의/철회한 결과 전달 | LLM의 임의 수락 |
| field.notification_route.read | 연결된 작업 사건의 현재 알림 책임 조회 | 임의 채널 발송 |
| field.connection.revoke | 이 연결 취소 | Field 사이트·예약·구독 삭제 |

`field.reservations.confirm`, 사이트 공개, Field 관리자, 결제, 원장 SQL 범위는 어떤 AP 도구에도 부여하지 않는다. Field도 AP 조직을 대신해 AI를 임의 공개하지 않는다.

초기 제안값: access token 10분, authorization code 60초·1회, refresh token은 rotation·재사용 탐지·명시 만료. 실제 유효기간은 선택한 인가 서버 제약과 보안 검토 후 고정한다. revoke endpoint·연결 상태 검사를 같이 두고, 단순히 refresh token만 지워 남은 access token을 계속 허용하지 않는다.[S02]

### 4.4 연결 상태와 도구 발견

제품의 단일 `connected=true` 대신 기능별 상태를 가진다.

| 상태 | 의미·동작 |
|---|---|
| pending_ap_consent | AP 권한 승인 전. 기존 Field는 정상 |
| install_only | AP 위젯 사용 가능. Field 데이터/예약 권한 없음 |
| pending_field_consent | 역방향 기능 승인 대기 |
| syncing / review_required | 데이터 동기화·사업자 정보 승인 대기 |
| active | 허용된 기능의 준비 상태 검수 완료 |
| degraded | 일부 API/동기화 실패. 이용 가능한 기능만 표시 |
| suspended / expired | 제재·구독·인가 사유로 해당 연결 기능 제한 |
| revoking / revoked | 로컬 사용 즉시 차단, 원격 폐기 재시도; 업무 원본 보존 |

`GET /integrations/v1/capabilities`는 `facts.read`, `availability.read`, `request.create`, `proposal.respond` 지원 여부와 스키마 버전을 반환한다. AP가 Field 전용 bool/SQL로 판단하지 않는다. 연결이 없는 AI는 기능 발견을 호출할 필요 없이 자체 FAQ·상담만 실행한다. 외부 앱이 예약 기능을 지원하지 않아도 커넥터와 AI가 실패하지 않게 한다.

### 4.5 승인 정보 동기화와 최신성

#### 원본과 승인 흐름

Field 변경 승인 → FieldCatalogRelease(version N) + outbox 생성 → signed facts.changed 이벤트 → AP가 해당 연결 API로 snapshot 조회 → source revision/hash 검증 → AP KnowledgeDraft에 변경안 → AP 사업자가 영향 확인 후 승인 → 새 AP KnowledgeRelease.

초기 기본값은 **가져온 변경을 AP에서도 검토 후 활성화**다. 최초 연결 후 모든 미래 가격을 자동 승인하는 정책은 기본으로 켜지 않는다. Field에서 한 승인과 AP 지식 공개 승인은 다른 제품의 별도 행위다. Field 연결 화면에서 AP 변경 검토로 이동하거나 AP의 공식 승인 화면을 사용할 수 있다.

Source 필드:

```text
source_id, provider, connection_id, external_org_id
source_revision, entity_versions, content_hash, published_at
fetched_at, approved_source_revision, ap_knowledge_release_id
state: current | pending_review | stale | unavailable | revoked
```

여기서 source_revision은 외부 제품이 부여한 비교 가능한 버전이고 AP KnowledgeRelease의 버전과 같지 않다. 순서가 뒤집힌 이벤트는 원본 상태를 과거로 돌리지 않는다. 누락된 revision은 snapshot 재조회로 복구한다. 같은 source/version/hash는 멱등, 동일 version+다른 hash는 integrity_conflict로 격리한다.

#### 가격·가용성의 엄격한 규칙

제품 간 한 DB 트랜잭션은 존재하지 않는다. 일반 소개·FAQ는 승인한 캐시와 마지막 확인 시각으로 안내할 수 있으나, **연결된 서비스의 가격·활성 상태·예약 조건을 수치로 제시하는 응답은 Field에서 현재 entity revision을 재확인**한다.

- Field 현재 버전과 AP가 승인한 버전이 같으면 근거로 사용한다.
- 다르면 새 값을 미승인 상태로 그대로 답하거나 예전 값을 최신이라고 답하지 않는다. 해당 필드는 검토 필요 안내·사람 문의로 전환한다.
- Field 조회가 실패하면 가격/가능 시간 확정 안내를 하지 않는다. AP 전체 상담실과 다른 native 지식은 계속 이용 가능하다.
- 무관한 다른 서비스의 변경은 해당 서비스 entity version이 동일하면 차단할 필요 없다. entity version을 제공하지 않는 커넥터는 전체 snapshot 버전을 엄격 비교한다.
- 최종 요청 제출에는 고객이 본 서비스 버전·조건 hash를 함께 보낸다. Field가 더 새 조건을 갖고 있으면409 `SOURCE_VERSION_CHANGED`로 최신 확인을 요구한다.

카드·사이트에서 가격을 복사한 정적 문구는 stale 검수 대상이다. 연결된 숫자는 가능한 라이브 바인딩으로 렌더하고, 확인 불가 시 ‘가격 확인 필요’로 바꾼다. 어떤 시점에도 전체 외부 사이트의 캐시가 동시에 바뀐다고 보장하지 않는다.

캐시 일반 확인 간격 5분, 소개자료 stale 24시간, 중요값 라이브 재확인은 제안값/실행 정책이다. 실제 주기와 모델 지연·API 부하를 측정하며 중요값 검사를 조용히 생략하는 최적화는 금지한다.

### 4.6 외부 요청과 예약 전달 — 분산 상태 처리

AP `ActionRequest`는 Field의 예약이 아니다. 외부 전달 원장과 예약 원장을 구분한다.

| AP 상태 | 고객에게 표시 | 다음 동작 |
|---|---|---|
| draft / awaiting_customer | 전달 내용을 확인해 주세요 | 고객의 명시 제출 |
| queued / sending | 문의는 저장됐으며 Field 전달 중 | 멱등 전송 |
| accepted_external | Field에 요청 접수됨, 아직 미확정 | 외부 ID 저장·사업자 응대 |
| delivery_unknown | 전달 결과 확인 중 | 원래 요청 ID로 Field 조회, 새 업무 생성 금지 |
| retryable_failure | 전달 지연, 다시 확인 중 | 같은 키로 제한 재시도 |
| rejected | Field가 접수하지 못함/조건 재확인 필요 | 원본 유지·고객 수정/직접 문의 |
| canceled_before_delivery | 고객이 전달 전 취소 | 큐 전송 차단; 이미 수신됐다면 외부 철회 요청 |

```json
{
  "action_request_id": "ar_example_001",
  "connection_id": "con_example_001",
  "kind": "reservation_request",
  "origin_conversation_id": "ap_thread_example",
  "external_service_id": "field_service_example",
  "expected_service_revision": 7,
  "customer": {"name": "테스트 고객", "phone": "01000000000", "verified": false},
  "request": {"mode": "preferred", "timezone": "Asia/Seoul", "preferences": ["2026-10-10 오전"]},
  "consent": {"version": "transfer-v1", "record_id": "consent_example", "confirmed_at": "2026-09-24T10:00:00Z"},
  "summary": "세탁기 청소 일정 문의",
  "attachment_refs": [],
  "source": {"provider": "agent-platform", "deployment_id": "dep_example", "is_test": true}
}
```

위 값은 테스트용 예시다. 외부 요청에는 고객 최종 확인의 감사 레코드·body hash를 묶고 signed/authenticated server 요청으로 전달한다. 이것은 휴대전화 실명 인증 증명이 아니다. `verified=false`는 수신 Field에도 보존한다. 프론트가 보낸 `is_test=false`를 신뢰하지 않고 서버의 테스트 세션에서 결정한다.

Field 처리:

1. 인증·scope·connection·동의 참조·대상 서비스·최신 조건·외부 요청 hash 검증.
2. `UNIQUE(provider, connection_id, action_request_id)`로 동일 업무를 하나만 수락. 같은 ID·다른 body면409.
3. Field 트랜잭션에 external_work_request·예약 requested·업무 수신 증빙·outbox 저장. 예약은 미확정이므로 점유 없음.
4.201/200 응답에 `external_request_id`, `reservation_id`(해당 시), `status=requested`, `version` 반환.
5. AP는 external ID가 확인된 경우에만 ‘Field 접수 완료’로 전환. 타임아웃은 unknown이며 같은 키로 조회/재시도.
6. 사장님이 Field 자체 승인 API에서 confirm. DB 충돌 검사 후 이벤트 발행. AP는 상태 미러만 갱신.

수신 조회 API는 AP가 저장한 action_request_id로 이미 수락된 건을 찾을 수 있어야 한다. 큐 재시작·이벤트 역순·연속 클릭도 별도 예약을 생성하지 않는다. 인터넷 전체에 exactly-once delivery가 있다고 가정하지 않고 at-least-once 전달과 멱등 업무 처리로 설계한다.

사진은 기본적으로 AP 원본의 짧은 권한 링크를 Field 서버가 인증된 API로 받아 고객이 전달에 동의한 자산만 복사·검사한다. 외부 body가 지정한 임의 URL을 fetch하지 않는다. Field가 수락한 업무 첨부는 자기 비공개 저장소에서 목적·출처·보존을 기록한다. 일부 첨부 복사가 실패하면 상태를 표시하고 본문 접수 성공과 구분한다.

### 4.7 대화·업무 UI와 고객 접근

AP가 원본인 대화는 Field BFF가 위임 API로 읽는다. 메시지 전송은 AP가 원본 event_id를 발급하고 AP에서 저장·AI 인계·알림을 처리한다. Field는 AP 문장을 자기 DB에서 따로 편집하거나 AP 장애 중 성공 메시지를 생성하지 않는다.

Field 직접 문의는 Field 원본이며 AP에 자동 이관하지 않는다. 고객 대화는 생성 제품의 상담 도메인에 남긴다. 제품 사이에 HttpOnly 쿠키를 공유하거나 전화번호로 로그인시키지 않는다.

Field에 확정된 예약이 있는 AP 고객에게 독립 Field 예약 확인 경로가 필요하면, **이미 인증된 AP 대화 권한 + 정상 connection + 연결된 reservation_id를 서버 간 검증**한 뒤 1회·짧은 수명·Field audience handoff를 발급한다. Field는 이를 자신의 예약 범위 capability로 교환한다. 이후 AP가 중단돼도 해당 Field 권한으로 예약 확인·변경 요청을 할 수 있다. 알림 링크나 외부 ID만으로 권한을 발급하지 않는다.

정상 연결 시 대화는 AP에서 유지하고 예약 상태·제안 UI는 허용 API를 사용한다. AP 장애/해제 후 새 연락을 위한 Field 후속 스레드가 필요하면 새 원본이라는 사실을 표시하고, 기존에 수신한 업무/예약과만 연결한다. AP 과거 대화 원문을 몰래 복제하지 않는다. 양방향 자동 transcript sync는 제외한다.

### 4.8 알림의 단일 책임

| 사건 | 기록 원본 | 정상 연결의 외부 알림 책임 |
|---|---|---|
| AP 일반 문의 제출/고객 추가 메시지 | AP | AP → 사업자 |
| AP 대화에서 사업자 답변 (AP 화면 또는 Field API) | AP | AP → 고객 |
| Field 직접 문의/답변 | Field | Field |
| AP가 넘긴 Field 예약 요청 수락 | Field 업무 + AP 전환 원장 | AP 한 번. Field 미러 생성에 별도 고객/사업자 알림 중복 금지 |
| 연결 AP 예약의 Field 확정/제안/변경 | Field | AP가 외부 사건을 기록한 뒤 고객 통지 |
| Field 직접 예약의 확정/변경 | Field | Field |
| 각 제품의 결제/보안/서비스 장애 | 해당 제품 | 해당 제품 |

원본 이벤트마다 `notification_owner_product`, `origin_event_id`, `connection_id`, `route_generation`을 저장한다. AP 대화/사용량 알림은 AP 구독에, Field 직접 업무는 Field 구독에 귀속한다. Field가 대신 AP 대화에 답변해도 AP 응답/메시지 비용을 Field 원장에 중복 차감하지 않는다.

Field→AP 사건이 지연되면 Field는 ‘예약 확정됨·고객 알림 전달 대기’를 표시한다. AP 장애를 이유로 Field가 동일 사건의 SMS를 자동 병행 발송하지 않는다. 원격 수신 ACK는 알림 최종 발송 성공이 아니다. AP가 처리·발송 결과 상태를 기록하고 Field는 정해진 API/이벤트로 조회한다.

연결 예약 사건의 발송 직전 AP는 Field의 알림 route/current generation·연결 상태를 확인한다. 확인할 수 없으면 보류한다. AP 자체 일반 대화의 알림은 Field 확인 없이 처리한다. 이 구분으로 AP 독립 운영을 유지한다.

**연결 해제 시 자동 발송 소유권 전환은 하지 않는다.** 기존 예약은 Field에 남기고 ‘직접 연락/알림 경로 재설정 필요’로 안내한다. Field의 유효한 고객 접근 경로와 필요한 고지/동의를 마련한 뒤 새 generation을 발급해 명시적으로 전환한다. 이전 generation에 속한 queued 이벤트는 폐기/대조 후 처리한다. 이미 공급사에 전달된 미상 메시지는 조회로 정리하고 곧바로 대체 발송하지 않는다. 긴급한 경우 사장님이 전화 등으로 직접 연락한 사실을 기록한다.

### 4.9 이벤트·멱등·재조정

두 제품은 각각 로컬 업무 commit+outbox를 같은 DB 트랜잭션에 저장한다. 원격 웹훅 수신은 서명 확인 후 inbox 원장에 durable 저장한 뒤202를 반환한다. 아직 저장하지 못하면2xx를 주지 않는다. 업무 처리·알림 생성은 이후 멱등 수행한다.

```json
{
  "spec_version": "1.0",
  "event_id": "evt_example_001",
  "event_type": "field.reservation.confirmed",
  "source_product": "field",
  "connection_id": "con_example_001",
  "aggregate_type": "reservation",
  "aggregate_id": "field_reservation_example",
  "aggregate_version": 3,
  "occurred_at": "2026-09-24T10:05:00Z",
  "correlation_id": "ar_example_001",
  "data": {"resource_id": "field_reservation_example", "status": "confirmed"}
}
```

웹훅 payload에는 원문·전화·주소·사진 URL·access token을 넣지 않는다. 필요한 원본은 scope가 있는 API로 조회한다. 등록된 client/connection과 source를 검증하며 body source 문자열을 믿지 않는다. `UNIQUE(source_product,event_id)`로 중복 제거하고 aggregate_version 역행·누락 시 최신 원본을 재조회한다.

초기 서명 계약은 제품 간 사전 등록된 연결별 secret의 **HMAC-SHA256**이다. 자체 프로젝트 계약이며 RFC와 동일한 메시지 서명 표준이라고 부르지 않는다. `X-Event-Id`, `X-Timestamp`(Unix seconds), `X-Key-Id`, `X-Signature`를 사용하고 서명 원문은 `timestamp + "." + event_id + "." + raw_body_bytes`다. 상수시간 비교, body/header event 일치, ±5분 시간창, 최대 body 크기, 키 교체를 검수한다. 재전송은 같은 event_id와 새 timestamp/서명으로 처리한다. secret은 브라우저에 제공하지 않는다.

일시 오류는 backoff+jitter, 한도 초과는 Retry-After,401/403은 재인가 또는 권한 조치로 구분한다. schema/동의/버전 오류를 무한 재시도하지 않는다. 제안값 8회·24시간 후 실패함,5분 단위 누락 재조정. 실제 재시도 횟수와 SLA는 실행 정책이다.

### 4.10 위젯·동일 조건 설치

Field는 공개 AP SDK를 설치한다. AP의 서버 프레임 응답은 CSP frame-ancestors로 허용 origin을 제한한다. meta 태그로만 설정하지 않는다.[S04] postMessage는 origin·source·nonce·허용 스키마·크기를 검사하고 부모에 대화/권한 비밀값을 전달하지 않는다.[S03]

일반 외부 사이트와 Field 모두 API 공개키와 세션 범위가 같다. origin 확인만을 사용자 인증이나 서버 abuse 방지로 간주하지 않는다. 공개 세션 발급·비용·사용량 제한과 risk 검사를 같이 수행한다. 설정할 수 있는 URL·redirect는 등록된 HTTPS 경로로 제한하고 SSRF/내부망/metadata 주소 fetch를 금지한다.

`owned_embed` 설치는 campaign_id, publisher_id 없이 동작한다. `partner_card`만 campaign release·publisher approval·slot 검사가 필요하다. Field도 그 구분을 따르며 모든 위젯을 광고로 처리하지 않는다.

### 4.11 연결 해제·장애·삭제

| 상황 | AP | Field |
|---|---|---|
| Field 전체 장애 | AP native 상담/다른 사이트는 정상. Field 중요 사실·예약 도구는 중단 | 자체 복구. AP와 무관한 데이터 보호 |
| AP 전체 장애 | 원격 AI/대화 불가를 정확히 표시 | 사이트·직접 문의·달력·기존 예약 정상. AP 전송은 미전송/대기 |
| 연결 revoke | 연결 source/도구/Field 배포·위임 권한 중지; 다른 native/외부 배포는 유지 | 토큰 폐기·원격 읽기/쓰기 차단; 직접 업무·수신 예약 보존 |
| AP 구독 종료 | 신규 AI/배포 제한·기존 상담 정리 | Field 구독·예약은 유지, 알림 경로 재설정 안내 |
| Field 구독 종료 | 다른 사이트의 AP는 유지, Field 신규 업무는 제한 상태 표시 | 자기 종료 정책·기존 예약 정리 |
| 한쪽 삭제 요청 | 해당 제품 원본·권한·법적 보존별 처리 | 이미 적법하게 수신한 원본의 목적·보존을 별도 판단 |

revoke 요청을 받은 서버는 로컬 실행을 먼저 차단하고 원격 폐기 요청을 durable 재시도한다. 원격이 오프라인이라 즉시 모든 토큰이 사라졌다고 표시하지 않는다. 사용 시 연결 상태/만료를 검증하며 유효한 요청도 scope 밖이면 거부한다. 법적 권리·약관상 필요한 양쪽 데이터 정정·삭제 요청은 추적 ID로 분리 전달하고 결과를 기록한다. 상대 동의 없이 전체 조직을 삭제하는 API는 없다.

Field source가 해제되면 그 값의 AP 사용을 중단한다. 데이터가 공개 정보였다는 이유로 AP native로 조용히 전환하지 않는다. 계속 쓰려면 권리와 최신성을 확인하고 AP 직접 등록·승인 절차로 새 source를 만든다. 다른 native source가 준비돼 있다면 그 범위의 상담은 유지한다.

### 4.12 공개 연동 API 최소 목록

#### AP 제공 — Field 및 검증된 외부 통합자가 사용

| 경로 | 권한/필수 입력 | 결과 |
|---|---|---|
| GET /integrations/v1/me | AP 위임 token | 허용 조직·AI·scope·grant 상태 |
| POST /integrations/v1/connections | 동의 transaction, 선택 AI | binding, 허용 기능 |
| POST /integrations/v1/connections/{id}/source-refreshes | ap.sources.refresh, 예상 source 버전 |202 sync_job |
| POST /integrations/v1/deployments | ap.deployments.manage, owned origin·agent | 설치 준비; 검증 후 활성 |
| GET /integrations/v1/conversations | read, 연결 제한 cursor | 최소 목록·출처·remote 상태 |
| GET /integrations/v1/conversations/{id}/messages | read, 범위·cursor | 원본 sequence |
| POST /integrations/v1/conversations/{id}/replies | user reply, message·revision·idempotency | 원본 message ID·저장/알림 상태 |
| POST /integrations/v1/connections/{id}/revoke | 해당 연결 manage | 로컬 차단·원격 revoke 상태 |
| POST /integrations/v1/webhooks/field | 등록 서명·event envelope |202 durable inbox receipt |
| GET /integrations/v1/events/{id}/delivery | 연결 사건 read | processed/notification status |

#### Field 제공 — AP 커넥터 및 동일 계약의 외부 앱이 사용

| 경로 | 권한/필수 입력 | 결과 |
|---|---|---|
| GET /integrations/v1/capabilities | Field 위임 token | 이 연결에서 지원/허용된 도구 |
| GET /integrations/v1/facts | field.facts.read, ETag/version | 승인 snapshot·entity version·hash |
| GET /integrations/v1/availability | scope, service_id·revision·from/to | 요청 가능 구간만 |
| POST /integrations/v1/external-requests | create, ActionRequest·consent·idempotency | external_request_id·requested 상태 |
| GET /integrations/v1/external-requests/by-source/{actionId} | read, binding | 타임아웃 뒤 기존 수락 확인 |
| GET /integrations/v1/external-requests/{id} | read, 연결 리소스 | 최신 상태·version·제안 |
| POST /integrations/v1/external-requests/{id}/customer-decisions | respond, exact proposal·customer proof | 동의/철회 상태. 확정 아님 |
| GET /integrations/v1/external-requests/{id}/notification-route | route.read | 소유 제품·generation·허용 여부 |
| POST /integrations/v1/customer-handoffs | read+범위 고객 증빙, 예약 ID |1회·Field audience 접근 교환 |
| POST /integrations/v1/connections/{id}/revoke | manage | 로컬 차단·원격 폐기 상태 |
| POST /integrations/v1/webhooks/agent | 등록 서명 |202 durable inbox receipt |

write의 Idempotency-Key는 제품+client+connection+operation 범위다. 같은 키·다른 body는409. 변경 객체에는 If-Match/expected_revision을 쓴다.400 입력,401 인증,403 권한,404 안전한 미존재,409 충돌/조건 변경,410 해제/만료,429 사용량,503 일시 장애를 명확히 반환한다. 응답은 `request_id`, `operation_id`(비동기), `state`, `retryable`을 포함하고 개인정보를 오류 문구에 넣지 않는다.

#### 계약 변경 정책

API major 버전과 event `spec_version`은 문서 release v3.0과 독립이다. enum 추가도 exhaustive client 영향 검토가 필요하다. 호환 가능한 추가는 contract test 후 적용하고 breaking 변경은 새 API major/dual support/이행 계획으로 처리한다. 최소 이전 지원 버전·지원 기간은 계약 정책으로 고정한다. 런타임은 모르는 필드를 조용히 권한으로 취급하지 않는다.

AP+Field 두 코드베이스가 공유할 수 있는 것은 versioned OpenAPI·JSON Schema에서 생성한 클라이언트와 명세다. domain service·repository·DB 타입·내부 ORM 모델은 공유하지 않는다.

---

## 05. 구현 구조·운영·제품별 출시

### 5.1 권장 저장소와 배포

한 monorepo를 관리 편의로 사용할 수 있지만, 제품별 실행·마이그레이션·배포·비밀키는 분리한다. 신규 저장소 설계안이며 기존 코드가 있다면 먼저 조사하고 ADR로 이행한다.

```text
apps/
  agent-web/             # AP 제품홈·관리실·고객상담·publisher·AP admin·BFF/API
  agent-worker/          # AP AI·알림·sync·배포·과금·삭제·이벤트
  field-web/             # Field 제품홈·제작실·사이트·직접문의·예약·Field admin·API
  field-worker/          # Field 사이트생성·공개·알림·과금·connector·삭제
packages/
  agent-domain/          # AP만 import
  agent-db/              # AP migrations/repositories
  field-domain/          # Field만 import
  field-db/              # Field migrations/repositories
  agent-contracts/       # AP 공개 schema/OpenAPI, 독립 버전
  field-contracts/       # Field 공개 schema/OpenAPI, 독립 버전
  generated-clients/     # 계약 기반 HTTP client; domain·DB import 금지
  ui/                    # 디자인 토큰·접근성 부품. 조직/권한·DB 로직 없음
  test-fixtures/         # 합성 데이터만, production 제외
examples/
  external-site/         # Field 코드 없이 AP SDK를 설치하는 최소 외부 사이트
infra/
  agent/                 # AP만 실행 가능한 compose/deploy/backup
  field/                 # Field만 실행 가능한 compose/deploy/backup
  integration/           # 두 제품·서로 다른 origin·오류 주입용 검증 환경
ops/                     # 제품별 runbook·게이트·실행 증빙
```

프레임워크는 TypeScript + 검수된 React/Next 계열 웹·서버, Node Worker, 제품별 PostgreSQL·큐·S3 호환 저장소를 시작안으로 한다. 실제 버전은 구현 시 공식 지원·호환·보안 확인 후 lockfile에 고정한다. 특정 프레임워크의 내부 서버 함수를 제품 간 API로 호출하지 않는다.

같은 Postgres 서버에 두 DB를 둘 수 있지만 런타임 계정은 상대 DB에 CONNECT/쓰기 권한이 없어야 한다. 백업·복구·확장도 따로 수행한다. Redis는 단순 key prefix만으로 격리됐다고 보지 않고 인스턴스 또는 ACL·큐 소비자 권한을 분리한다. 파일은 별도 bucket/policy·키로 분리한다. 별도 서비스가 같은 물리 서버의 공통 장애를 공유한다는 사실은 운영 문서에 남긴다.

각 제품 web/worker는 자기 DB와 인프라만 필요하다. 미연결 상대 URL/토큰은 optional이며 상대 healthcheck 때문에 자기 서비스 readiness를 실패시키지 않는다. 연동 상태는 별도 degraded 지표다. 공통 provider 장애를 제품 상호 의존 장애로 혼동하지 않는다.

### 5.2 agent용 런타임 의존 금지선

AP Core CI는 Field 디렉터리와 환경변수를 제외하고 build/migrate/test할 수 있어야 한다. Field Core CI는 AP domain/db를 제외하고 동일 검사를 수행한다. public client 생성물을 읽는 것은 가능하지만 상대 앱 실행이나 마이그레이션이 필수가 되어서는 안 된다.

금지 예: `agent-domain`이 Field 예약 service를 import, AP가 Field users를 JOIN, Field가 AP 조직 존재를 검사해 자기 로그인 허용, AP 설치 SDK가 Field 도메인에서만 발급, AP 위젯이 campaign/publisher 엔터티 없이는 로드되지 않는 것.

AP 입장에서 Field 커넥터는 one adapter implementation이다. `if (provider === 'field')` 분기 자체를 모두 금지할 필요는 없지만, core 도메인의 조직·상담·빌링이 그 provider를 필수로 요구하면 안 된다. provider 전용 매핑은 connector 경계 안에 둔다.

### 5.3 독립 계정·보안

두 제품에 이메일·카카오 로그인을 각각 제공한다. 이메일 소유 확인과 카카오 ID 검증, 명시적 계정 연결, 관리자의 추가 인증, 세션 회수·CSRF·출력 이스케이프·허용 리디렉션 검수를 유지한다. AP 계정/Field 계정이 동일인이라도 membership과 이용 동의는 별도다.

제품별 관리자 권한은 각각 부여한다. 하나의 회사 운영자가 두 콘솔을 사용할 수는 있지만 Field admin 토큰으로 AP 대화 원문을 열지 못한다. 지원 접근은 사유·요청·기간·감사 로그를 요구하며 무제한 impersonate를 제공하지 않는다.

모든 비공개 API·파일·큐 작업·캐시·export·LLM 근거에 조직 scope와 원본 제품을 반영한다. DB RLS만으로 보안이 끝났다고 보지 않고 서비스 권한·DB role·우회 권한·테스트를 함께 둔다. 상대 토큰을 고객의 신원 인증이나 대화 접근용 bearer로 재사용하지 않는다.

### 5.4 두 제품의 구독·비용

| 항목 | 규칙 |
|---|---|
| AP 구독 | AI·상담·기본 설치·사용량·AP 알림. Field 구매 불필요 |
| Field 구독 | 사이트·제작 AI·직접 문의·예약·도메인·Field 알림. AP 구매 불필요 |
| 연결 | 별도 제품 이용 조건과 권한 확인. 연결만으로 청구 없음 |
| 무료 체험 | 각 제품 14일·카드 없이 시작은 제안값. 새 제품 체험을 악용해 기존 제품 크레딧을 충전하지 않음 |
| 독립 가격 | 기존 통합안 29,000원은 자동 승계하지 않음. 가격/세금/제공량/최초 결제일/환불 조건의 승인 plan 필요 |
| 초과 사용량 | 경고·제한·명시적 구매. 동의 없는 초과청구 금지 |
| 묶음 판매 | 후속 계약/정산/혜택 원장으로 다룸. 이번 필수 범위 아님 |
| 고객 서비스 대금 | 두 제품 모두 수령·정산하지 않음 |

과금은 각 제품의 `(subscription_id, billing_period)` 유일 원장과 동의 버전으로 처리한다. 공급사 timeout은 같은 거래 조회 후 해결하며 새 주문으로 이중 청구하지 않는다. 환불/해지는 명확히 구분하고 하나의 제품 해지로 상대를 자동 취소하지 않는다.

PG가 동일 사업자 계약을 사용할 수 있는지, 메시지 발신 주체/채널/템플릿이 두 제품에 적합한지 공급사와 확인한다. 같은 회사이니 승인이 자동 승계된다고 가정하지 않는다. 키와 내부 비용 원장은 계약 형태와 무관하게 제품별이다.

### 5.5 개인정보·약관·보존

AP 회원·Field 회원·AP 상담·Field 직접 상담·고객이 Field에 제출한 작업 스냅샷을 구분해 목적·주체·위탁/제공 관계를 실제 계약으로 검수한다. 제품이 분리되었다는 이유만으로 모든 이동이 반드시 제3자 제공이라고 단정하지도, 같은 회사라는 이유로 고지가 필요 없다고 단정하지도 않는다. 외부 LLM·파일·CDN·로그·백업의 처리 위치·재학습·보존·하위 처리자도 검수한다.

고객에게 전달 목적·대상 사업자·제품·필드·필요 고지와 동의를 명확히 제공한다. 제품 간 공통 고객 번호 DB·고객 프로파일 판매·학습자료 자동 공동 사용은 금지다. AI 고지·광고 표시·소비자 권리·구독 약관은 실제 출시 법령과 계약을 별도 법무 게이트로 확인한다. 이번 문서는 법률 준수 인증이나 법률 의견서가 아니다.

| 데이터 | 보존 시작안 | 중요 조건 |
|---|---|---|
| 접수 없는 익명 AI 대화 | 마지막 활동 후30일 | 통계는 재식별 위험 검수 |
| 정식 문의/업무 요청 | 종결 후180일 | 예정 업무·분쟁·법정 기록은 분리 |
| 고객 사진 | 종결 후90일 | 제품별 수신 사본도 목적·기한 기록 |
| 원문 모델 debug | 기본 저장 안 함 | 예외 접근/기간 제한 |
| 기술 로그 | 마스킹30일 | 인증/고객 비밀값 제외 |
| 감사 로그 | 1년 제안 | 법령·계약 의무별 재설정 |
| 백업 | 제품별 순환30일 제안 | 복원 후 삭제·revoke 원장 재적용 |
| 연결 비밀값 | 해제 즉시 사용 차단·폐기 | 최소 감사메타·분쟁 증빙만 별도 보존 |

법정 거래 기록은 해당 제품의 구독·청구 원장으로 분리 보존한다. 전체 채팅을 무조건 법정 기간 동안 보관하는 방식으로 확대하지 않는다. 상대가 적법하게 수신한 데이터의 삭제 결과는 별도 작업과 증빙으로 관리한다.

### 5.6 운영 목표와 관측

제안 목표: 각 제품 일반 접수 저장 p95 2초(파일/모델 제외), 정상 큐 발송 시도 p95 10초(묶음/공급사 제외), 각 제품 DB RPO15분·객체60분·핵심복구 RTO4시간. 계약상 SLA나 실측 성과가 아니다.

별도 지표: AP 첫 AI 활성화, 외부 사이트 설치 성공, 상담 인계율, 답변 지연, 모델 비용, Field 사이트 공개 완료, 실제 문의 처리, 예약 확정, connector 전달 지연/unknown/중복 차단, 승인 source 최신성, 중복 알림, 서로 독립인 구독 전환·재결제. 매체는 집계만 보고 예약 확정을 실제 매출·수금으로 표시하지 않는다.

AP 장애가 Field 직접 접수 오류율로 번지지 않는지, Field 장애가 AP native 질의를 끊는지 별도 synthetic probe로 확인한다. 제품별 이벤트·로그·원가를 보되 correlation_id로 허용된 장애 추적을 가능하게 한다. 상관 ID에 전화번호를 넣지 않는다.

### 5.7 출시 게이트

| 게이트 | 대상 | 실제로 남길 증빙 |
|---|---|---|
| G-A1 | AP 가입/요금/자체 운영 | Field 미배포 상태에서 자체 가입·실구독·해지·내보내기 |
| G-A2 | AP 외부 설치/사람 응대 | 일반 외부 사이트의 별도 origin·실기기·고객 접수·AP 답변 |
| G-A3 | AP AI/알림/복구 | 실제 LLM, 카카오/문자/푸시 승인·콜백, 원본/파일 복구 |
| G-F1 | Field 단독 제작/도메인 | AP 환경변수 없는 셀프 제작·실제 제작 LLM·기본/자체 도메인 |
| G-F2 | Field 직접 문의/예약 | AP 차단 상태의 두 예약 방식·실알림·수동 일정·동시성 |
| G-F3 | Field 구독/보안/복구 | 실청구·취소·해지·권한·백업/삭제 복원 방지 |
| G-I1 | 공개 연동/권한 | 두 방향 scope·동의·actor·issuer·재인가·revoke 검수 |
| G-I2 | 데이터/업무 전달 | stale 가격·버전 충돌·타임아웃·중복·개인정보 인계 |
| G-I3 | 알림·단절 복구 | 원본별 한 발송 주체·unknown·해제 중 기존 예약·토큰 회수 |
| G-D1 | 홍보·매체 | 사업자/매체의 정확한 버전 승인, 도메인 권한·고지·중지 |
| G-D2 | 성과·프라이버시 | AP만으로 집계, 작은 집단/차분 완화·PII 차단 |
| G-L1 | 실제 운영 계약 | 두 제품 약관/데이터 책임/국외 처리/AI고지·PG·메시지 계약 검수 |
| G-S1 | 전체 최종 인수 | 변경 추적표·모든 적용 QA·제품별 독립/연결 회귀·책임자 승인 |

각 독립 릴리스는 자기 게이트와 공통 법무·보안 적용 항목만으로 판단한다. 예를 들어 AP Core가 G-D1을 기다릴 필요는 없지만 Distribution을 완료했다고 주장할 수는 없다. 전체 Suite 완료는 모든 적용 게이트를 요구한다. credential 없음·법무 검수 미완료·테스트 skip은 통과가 아니다.

### 5.8 마이그레이션 — 이미 구현된 경우만

현재 자료는 기획/시안이므로 운영 DB가 존재한다고 가정하지 않는다. 신규 개발은 두 DB로 시작한다. 기존 v2.0 서버가 실제 존재한다면 먼저 read-only 인벤토리·백업·보존 근거·원본 건수를 확보한다.

1. cross-product schema·mapping·인증·버전 계약을 추가하고 기존 서비스는 즉시 삭제하지 않는다.
2. AP 원본으로 이전할 실제 AI/지식/대화와 Field 원본으로 남길 사이트/직접 문의/예약을 출처와 기능 기준으로 분류한다. 출처 불명 대화를 AI 원본으로 추정하지 않는다.
3. 제품별 조직을 새로 만들되 연결/계약/고지/과금 동의를 마련한다. 기존 카카오 로그인·비밀번호·PG billing key를 몰래 복사해 두 구독을 만들지 않는다.
4. 승인된 공개 정보만 source로 매핑하고 기존 사용자의 초안·중지 상태·예약 스냅샷·대화 권한을 보존한다.
5. 작업 단위 write freeze 또는 검증된 변경 캡처로 이행 경계를 잡는다. 승인 없는 무한 dual write 금지. 건수/hash/권한/정산·알림 책임을 대조한다.
6. 허용된 대상부터 canary 전환, 오류 시 이전 읽기/쓰기 경로로 안전 복귀. 실제 새 메시지·예약을 버리는 DB 전체 롤백 금지.
7. 이전 URL은 원본 권한을 검사하는 안전 전환/안내를 제공한다. 전화번호로 새 세션을 발급하지 않는다.
8. 법적 보존·대조·복구 검수가 끝난 뒤 중복 필드를 제거하고 이행 종료 증빙을 남긴다.

### 5.9 공식 기술 참고자료

확인일 2026-09-24. 아래는 표준/브라우저/벤치마크 확인이며 우리 구현의 승인·보안 인증을 의미하지 않는다. 문서의 구체적인 제품 경계·기간·스키마·알림 소유 규칙은 별도 실행 설계다.

| ID | 출처 | 적용 |
|---|---|---|
| S01 | [RFC 9700 — OAuth 2.0 Security BCP](https://www.rfc-editor.org/rfc/rfc9700.html) | code+PKCE, 정확한 redirect, scope/audience 제한, refresh 보호 |
| S02 | [RFC 7009 — Token Revocation](https://www.rfc-editor.org/rfc/rfc7009) | 토큰 회수 API와 철회 처리 |
| S03 | [MDN — Window.postMessage](https://developer.mozilla.org/en-US/docs/Web/API/Window/postMessage) | exact target origin·수신자 검증 |
| S04 | [MDN — CSP frame-ancestors](https://developer.mozilla.org/en-US/docs/Web/HTTP/Reference/Headers/Content-Security-Policy/frame-ancestors) | 실제 응답 헤더·ancestor 허용 범위 |
| S05 | [MDN — Third-party cookies](https://developer.mozilla.org/en-US/docs/Web/Privacy/Guides/Third-party_cookies) | 외부 삽입 세션과 1차 도메인 전환 분리 |
| S06 | [Firsthand — Platform](https://www.firsthand.ai/platform) | 독립 브랜드 AI 생성·배포라는 개념 참고. 기능 동등성/API 계약은 아님 |

기존 PRD의 법령·메시지 단가·구체 라이브러리 선택은 최신 가격/계약 승인이 아니다. 공개 출시의 G-L1 및 제품별 공급사 게이트에서 재확인한다.

---

## 06. 기존 역할과 UI v3의 개정 지도

이번 작업은 개발 계획 개정이다. 기존 `field_ui_prototype_v3.html`을 새 제품 구조로 재구현했다고 표시하지 않는다. 기존 디자인·사이트 제작·고객·사업자·매체·관리자 기능을 보존하되 소유 제품과 이동 경로를 아래처럼 고친다.

### 6.1 역할·제품별 화면

| 기존 항목 | 개정 소유 제품 | 수정할 흐름 |
|---|---|---|
| Field 플랫폼 홈 | Field | ‘홈페이지 만들기’ 중심, ‘AI만 도입’은 별도 AP 제품으로 안내 |
| AI만 도입하기 | AP 홈페이지/개설실 | Field 가입·사이트·예약을 요구하지 않음 |
| 사업자/서비스 제공자/광고주 | 각 제품 owner | 불필요한 3개 역할 계정은 만들지 않되 AP/Field 조직·동의는 별도 |
| 셀프 사이트 5단계 | Field | 원래 기능 유지, AI 상담 연결은 선택 단계 |
| 내 사이트 / 제작 AI | Field | 자체 제작 LLM·초안·공개·복구 |
| 내 사업 AI | AP | 지식·응대 테스트·설치·활성화·사용량 |
| Field의 AI 메뉴 | Field 연동 서비스 | 연결/권한/동기화/설치 상태·AP 관리실 이동 |
| 홍보 카드·공유·매체 배치 | AP | 자체 위젯 설치와 광고 캠페인을 분리 |
| 문의함 | 양쪽 각각 | Field는 자기 직접 대화+허용된 AP 목록을 합성; AP 원문은 공식 API |
| 예약·달력 | Field | AP에서 요청은 가능하지만 원본·확정은 Field |
| 고객 AI 상담·후속 대화 | AP | AP 도메인·권한·알림, Field 예약 상세는 안전 handoff |
| 고객 직접 문의·예약 | Field | AP 없어도 기존 양식/통화/후속 대화 유지 |
| 제휴 매체 | AP | 위치·배치·승인·집계, Field 고객 데이터 열람 불가 |
| 플랫폼 관리자 | AP admin / Field admin | 각각 권한·MFA·로그·구독·운영 장애. 통합 superuser 금지 |

### 6.2 Field에 표시할 연결 화면의 필수 상태

| 상태 | 표시 | 행동 |
|---|---|---|
| 미연결 | ‘AI 상담은 별도 서비스를 연결해 이용합니다’ | 계정 연결 / AP 가입 / 나중에 |
| 설치만 연결 | ‘AI 상담 사용 중 · 예약 연동 없음’ | Field 정보/예약 권한 추가 승인 |
| 정보 검토 필요 | 변경된 서비스·가격·영향 접점 | AP 정보 검토로 이동 |
| 사용 가능 | 선택 AI·배포 주소·권한·마지막 검증 | 테스트 / 설정 / AP 관리실 |
| 일시 장애 | 직접 문의·예약 정상, AI 또는 원격 대화 제한 | 상태 확인 / 직접 문의 경로 |
| 해제 중 | 로컬 차단 완료·원격 토큰 회수 대기 | 기존 예약 처리·알림 경로 점검 |
| 해제 | Field 업무는 유지, AP 원문 접근은 없음 | 재연결 / AP 직접 관리실 안내 |

### 6.3 승인/정상 상태를 과장하지 않는다

‘연결됨’은 모든 source가 최신 승인이라는 뜻이 아니다. ‘요청 저장’은 외부 Field 접수 완료가 아니며, 외부 접수도 예약 확정이 아니다. ‘원격 이벤트 수신’은 고객 알림 전달이 아니다. 외부 callback 대기나 stale 상태를 초록 체크 하나로 대체하지 않는다.

AI가 설치되지 않은 Field 사이트에는 동작하지 않는 ‘AI에게 문의’ 버튼을 노출하지 않는다. 실제 앱에서 시안 상단 역할 탭은 제거하고 로그인·권한별 제품 라우팅을 적용한다. 검토용 UI가 필요하면 별도 데모 배너와 합성 데이터 환경에 한정한다.

### 6.4 디자인 계약 유지

Apple 계열의 단순한 화이트·밝은 그레이, 시스템 폰트, 여백, 블루 주요 행동, 최소 경계를 유지한다. 모든 표시 텍스트 최소14px, 본문/입력16px, 조작 영역44px급을 지향한다. 외부 위젯도 14px 미만으로 축소하지 않는다. macOS/iOS 기본 폰트를 참조하되 폰트 파일을 배포하지 않는다.

320/390/768/1440px·200% 확대·키보드·스크린리더·동작 감소를 검수한다. Field 모바일 오늘/문의/예약/내 사이트/더보기는 유지한다. AP 모바일은 AI/문의/설치/더보기 중심으로 별도 구성하고, 매체도 운영/위치/요청/성과/설정을 유지한다. 화면마다 빈 상태·저장·오류·미연결·권한 거부·한도·동기화 지연을 구현한다.

### 6.5 실제 사용자 인수 시나리오

**외부 사업자:** AP 가입 → 직접 정보 등록 → AI 승인 → Field와 무관한 기존 사이트 설치 → 고객 질문 → AP 문의함에서 답변 → AP 구독.

**Field만 쓰는 사업자:** Field 가입 → 자기 사이트 제작 → 공개 → 직접 문의와 두 예약 방식 → 자체 알림 → Field 구독. AP가 없다는 이유로 메뉴를 막지 않음.

**두 제품을 쓰는 사업자:** 각 제품의 조직·요금 확인 → 공식 연결 승인 → Field 공개 정보 동기화 검토 → 같은 AP SDK 설치 → 고객 상담 → Field 업무 요청 → Field 관리실에서 API 답변·예약 승인 → 고객은 원래 대화에서 결과 확인.

**매체:** AP 매체 조직 → 도메인/위치 확인 → 사업자 공개 카드의 정확한 버전 승인 → 별도 origin에서 표시 → AP 안전 접수 → 집계만 조회. Field가 없어도 일반 상담 광고 실험 완료.

**운영자:** 제품별 콘솔 → 자기 권한 범위의 장애/신고 확인 → 사유·기간·증빙으로 조치 → 연동 문제는 correlation_id와 최소 메타데이터로 협업. 관리자 세션을 다른 제품에 그대로 제출하지 않음.

---

## 07. 요구사항 추적과 인수 검수 160개

**기존 QA01~QA120의 ID를 보존하고 제품 경계에 맞게 기대값을 개정했으며, 독립성·연동 QA121~QA160을 추가했다. 아래는 실행해야 할 인수 명세이고 이번 문서 작성 중 실서비스 테스트가 통과했다는 뜻이 아니다.**

제품별/공통으로 표시한 행은 해당 제품에서 각각 검수한다. AP 승인으로 Field 검수를 대신하지 않는다. Core 릴리스에 없는 매체/연동 QA는 적용 외로 구분하고, 전체 Suite에서는 해당 항목도 실행한다. provider credential 부재는 적용 외가 아니라 blocked_integration이다.

### 기존 테스트의 중요한 개정

공유 DB 원자성→제품내 원자성+동기화 상태, AI-only 동일 조직→별도 제품 조직+동의 mapping, 통합 과금→독립 원장, 동일 브라우저 시안→실제 독립 서버/기기 검수로 바꿨다. 전체 기존 21개 요구의 삭제는 없다.

| ID | 적용 | 시나리오 | 통과 조건 |
|---|---|---|---|
| QA01 | 제품별/공통 | 공개 가입·사업체 생성 | 수동 승인 없이 정상 가입, 사용자별 한도 적용 |
| QA02 | 제품별/공통 | 이메일 로그인·만료 링크 | 유효 링크만 허용, 중복 사용·만료 처리 |
| QA03 | 제품별/공통 | 카카오 로그인·이메일 미제공 | 이메일 없이도 안전한 계정 경로, 필요한 정보 별도 입력 |
| QA04 | 제품별/공통 | 같은 이메일의 다른 로그인 | 자동 병합 없이 기존 계정 재인증 후 연결 |
| QA05 | 제품별/공통 | 다른 사업체 API/파일 접근 | ID·tenant 변경으로 데이터 접근 불가 |
| QA06 | 제품별/공통 | 사업자 번호 변경·세션 폐기 | 최근 확인·기존 기기 세션·보안 알림 처리 |
| QA07 | Field | 템플릿 시작과 AI 시작 | 같은 편집/공개 모델로 끝까지 진행 |
| QA08 | Field | AI의 임의 코드·허위 정보 삽입 | 스키마 밖 변경 차단, 사실 미확인 값 경고 |
| QA09 | Field | 여러 페이지·서비스 상세·모바일 | 연결·CTA·반응형 정상, 페이지 한도 일치 |
| QA10 | Field | 초안 수정 중 실제 사이트 | 공개본에 초안이 노출되지 않음 |
| QA11 | Field | 사실·사이트 공개 중 일부 실패 | Field 내부 공개의 원자성은 Field DB에서 검수. AP 동기화는 별도 상태·승인·stale 처리로 검수하며 분산 원자성을 주장하지 않음 |
| QA12 | Field | 공개 버전 복구 | 과거 디자인을 초안으로 복구, 현재 승인 사실·예약·대화·결제는 유지 |
| QA13 | Field | 정상 자체 도메인 연결 | 소유 확인·TLS·DNS 확인 후 해당 사이트 연결 |
| QA14 | Field | 타인 도메인·잘못된 Host | 다른 사업체 사이트/데이터로 연결되지 않음 |
| QA15 | Field | DNS 이탈·인증서 오류·재연결 | 상태 안내, 기본 주소 유지, 재검증 |
| QA16 | 제품별/공통 | AI 질문 후 직접 문의로 전환 | AP 대화에서 직접 접수로 전환할 때 맥락 유지. Field로 넘어갈 경우 수신 범위·고객 동의·원본 분리 |
| QA17 | 제품별/공통 | 비회원 이름·번호 접수 | OTP/회원가입 없이 접수, 미인증 상태 표시 |
| QA18 | 제품별/공통 | 번호 오입력·다른 브라우저 링크 | 링크/번호만으로 본문·사진·과거 내역 공개 안 됨 |
| QA19 | 제품별/공통 | 접수 확인키·잘못된 키 반복 | 해당 대화만 접근, 횟수 제한·폐기 작동 |
| QA20 | 제품별/공통 | 악성/과대/HEIC 첨부 | 안전한 검사·변환·재첨부, 다른 필드 손실 없음 |
| QA21 | 제품별/공통 | 사람 인계 중 AI 생성 완료 | 고객에게 AI·사람 동시 발송 안 됨 |
| QA22 | 제품별/공통 | 등록되지 않은 가격·가능 여부 | 임의 약속 없이 미확인/사람 인계 |
| QA23 | 제품별/공통 | 프롬프트 공격·타 사업자 정보 요구 | 권한 밖 도구/정보 반환 없음 |
| QA24 | 제품별/공통 | AI 오류·한도·공급사 중단 | AP LLM 장애에도 AP 사람 응대/양식 정상. AP 전체 장애에도 Field 직접 문의 정상 |
| QA25 | Field | 희망시간형 신청 | 미확정 요청으로 저장, 필요 시간 조율 |
| QA26 | Field | 시간표형 신청 | 서비스 시간·휴무·완충·현재 점유 반영 |
| QA27 | Field | 다른 서비스의 같은 시간 | 동일 사업자 자원에서 중복 확정 차단 |
| QA28 | Field | 같은 슬롯 복수 요청 | 요청은 저장, 서로 다른 두 확정은 불가 |
| QA29 | Field | 동시에 승인 버튼 두 번 | DB에서 한 번 처리, 알림 중복 없음 |
| QA30 | Field | 전화 예약 수동 등록 | 고객 사이트 시간표에 즉시 반영 |
| QA31 | Field | 새 시간 제안·고객 수락 | 고객 동의 기록, 사업자 최종 승인 전 확정 금지 |
| QA32 | Field | 확정 예약 시간 변경 | 새 점유 성공 전 기존 점유 유지, 원자적 교체 |
| QA33 | Field | 취소·거절·만료·노쇼 | 각 상태와 책임 구분, 법적 안내/알림 적합 |
| QA34 | Field | 자정·완충·휴무·조건 변경 | 날짜 경계와 기존 예약 스냅샷 정상 유지 |
| QA35 | 제품별/공통 | 사업자 알림 조건 | 단순 AI 안내는 제외, 처리할 일은 카카오/푸시 |
| QA36 | 제품별/공통 | 고객 알림톡 실패→문자 | 등록 발신번호·단일 대체 주체, 중복 없음 |
| QA37 | 제품별/공통 | 고객 미열람·공급사 결과 미상 | 미열람만으로 문자 발송 안 함, 결과 조회 |
| QA38 | 제품별/공통 | 중복·역순 콜백·Worker 재시작 | 원장 최종 상태·차감 한 번, outbox 재구성 |
| QA39 | 제품별/공통 | iPhone PWA·Android·PC 푸시 | 설치/권한/거부/무효 토큰 처리, 잠금화면 민감정보 없음 |
| QA40 | 제품별/공통 | 알림 한도 소진·수신 신고 | 저장 유지·명확한 미전달 상태·비용 차단 |
| QA41 | 제품별/공통 | 사장님 답변 후 고객 재방문 | 접수 대화 연결, 사이트 밖에서도 양방향 진행 |
| QA42 | 제품별/공통 | 카드 없는 체험 시작·종료 | 14일 제안값 준수, 동의 없는 자동 결제 없음 |
| QA43 | 제품별/공통 | 구독 신청·첫 결제·월말 갱신 | 동의한 금액/주기·월말 규칙·원장 정상 |
| QA44 | 제품별/공통 | 결제 타임아웃·중복 콜백 | 새로운 청구 중복 생성 없이 PG 상태 대조 |
| QA45 | 제품별/공통 | 구독 해지·실패 유예·환불 | 다음 갱신 중지·기존 기간 유지·환불 기록 |
| QA46 | 제품별/공통 | 구독 종료 후 예정 예약 | 각 제품 신규 기능 제한과 정리 모드 분리. 한 제품의 해지로 상대 구독/기존 예약을 가두지 않음 |
| QA47 | 제품별/공통 | DB/파일 복구·삭제 재적용 | 독립 환경 복구, RPO/RTO 실측·삭제 복원 방지 |
| QA48 | 제품별/공통 | 공개 가입 악용·알림 폭탄 | 위험 범위만 제한·비용 상한·신고/이의 처리 |
| QA49 | 제품별/공통 | 운영자 열람·지원 접근 | 승인/사유/기간/감사 기록 없이 상세 열람 불가 |
| QA50 | 제품별/공통 | 전체 실제 연락 흐름 | Field 단독 직접 흐름과 AP 연결 흐름을 각각 별도 실제 기기에서 검수 |
| QA51 | Field | 플랫폼 루트와 고객 사이트 분리 | 플랫폼 루트는 만들기·가입, tenant 도메인은 해당 공개본. 샘플 고객 사이트로 시작하지 않음 |
| QA52 | Field | 신규 가입자 첫 화면·빈 상태 | 사이트 없음→만들기, 문의·예약 0건. 샘플 영업 데이터 없음 |
| QA53 | Field | 실제 사업 정보 바인딩 | 세차·촬영·레슨 정보가 Field 초안/공개본에 반영. 연결 AP는 해당 소스 버전 승인 후 반영 |
| QA54 | Field | 템플릿·실제 AI 생성 두 경로 | 둘 다 같은 스키마로 개설 완료. 운영 AI 경로가 키워드 데모로 대체되지 않음 |
| QA55 | Field | 템플릿 배치 차이 | 3개 템플릿이 색상뿐 아니라 대표 영역·사진·정렬에서 다르게 렌더링 |
| QA56 | Field | 사업자 사진 업로드·실패·새로고침 | asset 상태·재첨부·서버 저장·공개 반영. 로컬 썸네일을 저장 성공으로 오인하지 않음 |
| QA57 | Field | 320~1440px 글자·접근성 | 320·390·768·1440px에서 표시 글자 최소 14px, 주요 경로 가로 넘침·키보드 가림 없음 |
| QA58 | Field | 모바일 편집/미리보기 전환 | 입력·선택 유지, 좁은 화면에 다열 압축/축소 텍스트 없음 |
| QA59 | Field | 섹션 순서·삭제·필수 CTA | 모바일 버튼·키보드로도 편집, 공통 문의 액션·tenant 보호 |
| QA60 | Field | 페이지 추가·이름·경로·삭제 | 페이지 한도·홈 유지·내부 링크·공개 경로 처리 일치 |
| QA61 | Field | 제작 중 이탈·기기 변경 | 서버 마지막 저장본과 유효 단계에서 재개, localStorage만 의존하지 않음 |
| QA62 | Field | 자동 저장 실패·오프라인 | 미저장 표시·입력 보존·안전 재시도, 공개본 변화 없음 |
| QA63 | Field | AI 생성 대기·실패·취소·재시도 | 입력/초안 보존·단일 job·중복 차감 없음·템플릿 대체 가능 |
| QA64 | Field | AI 대기 중 수동 수정·다중 탭 | base_revision 충돌 감지, 최신 입력 자동 덮어쓰기 금지 |
| QA65 | Field | 초안·미리보기 접근 | 비로그인/다른 tenant가 토큰·경로 변경으로 미공개 정보 읽기 불가 |
| QA66 | Field | 공개 전 연락·서비스·시간표 검사 | Field 필수 연락·서비스·예약 검수는 유지하되 AP 미연결만으로 공개를 차단하지 않음 |
| QA67 | Field | 자체 도메인 대기 중 첫 공개 | 기본 주소로 공개·운영 가능, 자체 도메인 준비와 상태 분리 |
| QA68 | Field | 개설 완료와 다음 행동 | Field 사이트 확인/테스트와 AP 선택 연결을 구분; 실제 운영 주소만 성공으로 표시 |
| QA69 | Field | 첫 문의 테스트 안전성 | 서버 테스트 플래그, 자기 검증 수신처만 발송, 실적·실제 일정 점유 제외 |
| QA70 | Field | 예시 데이터 격리 | 운영 tenant에 데모 고객/예약/리뷰/관리자 샘플 초기 삽입 없음 |
| QA71 | Field | 단계 URL 직접 접근·재로그인 | 서버 readiness/권한 검사, 공개 후 기본은 오늘, 기존 업무 접근을 온보딩으로 잠그지 않음 |
| QA72 | Field | 과거 버전 복구 후 공개 | 활성 포인터 유지→복구 초안 검수→재승인→새 디자인 릴리스. 과거 가격 복구는 별도 승인 |
| QA73 | Field | 디자인 교체·재생성 | 사업 정보·수동 편집 보존 또는 변경 확인, 내용 자동 유실 없음 |
| QA74 | Field | 공개본이 쓰는 사진 삭제 | 초안 교체만으로 현재 공개 사진을 삭제하지 않음, 참조 정리·보존 동작 |
| QA75 | Field | 생성/공개 Worker 재시작 | Field 생성/공개 Worker 멱등·revision 검수. AP sync는 별도 outbox·소스 승인 상태이며 Field 공개 실패와 구분 |
| QA76 | Field | 시안 역할 탭·관리자 접근 제거 | 운영 배포에서 버튼/URL만으로 다른 역할 전환·대화 열람 불가 |
| QA77 | Field | 개설 때 설정한 두 예약 방식 | 서비스별 예약 설정이 공개 사이트·일정·관리실에 일치, 임의 전역 덮어쓰기 없음 |
| QA78 | Field | 실제 서로 다른 기기의 접수·답변 | 고객 기기→서버→사업자 기기→고객 후속 확인, 같은 브라우저 데모로 대체 금지 |
| QA79 | Field | 공개 SEO·미공개 보호·가격 일치 | 각 제품 초안 비공개·승인 원본 유지. 연결 가격은 live version 일치 또는 확인 필요로 처리 |
| QA80 | Field | 셀프 개설 전체 흐름 | Field 가입·자기 정보·템플릿/실제제작AI·공개·직접문의·예약을 AP 없이 완료. 연결 흐름도 별도 검수 |
| QA81 | AP | AI 단독 가입 | AP 전용 가입·DB·조직·지식·활성화·상담이 Field 사이트/계정/서버/예약 없이 완료 |
| QA82 | Field | 기존 사이트 경로 보존 | 신규 사업자는 5단계 셀프 제작, 사업자가 직접 공개 |
| QA83 | 연동/AP | AI-only에서 사이트 추가 | AP 고객이 Field에 별도 동의/가입하고 기존 AI를 연결. AP와 Field 조직은 별도며 무단 고객/예약 복제·중복 청구 없음 |
| QA84 | 연동/AP | 승인 사실 변경 | Field source 변경을 AP 검토·버전 대조 후 반영. 미승인/미상 가격은 단정하지 않으며 기존 예약 snapshot 불변 |
| QA85 | 연동/AP | 디자인 복구와 사실 복구 | Field 디자인 복구가 AP 사실·설정·중지를 변경하지 않음. 각 사실 복구는 별도 승인 |
| QA86 | 연동/AP | AI 배포별 권한 | 같은 AP agent의 배포 권한을 검사하고 선택 Field 도구는 연결 scope에서만 사용 |
| QA87 | AP·배포 | 카드 초안 편집 | 공개 카드와 매체 live 내용 불변, draft preview만 변경 |
| QA88 | AP·배포 | 카드 공개 동의 | 사업자 명시 승인·revision·idempotency, stale 승인 거부 |
| QA89 | AP·배포 | 허위 가격/주장 삽입 | 승인 사실과 충돌하는 카드 약속을 차단 또는 수정 확인 요구 |
| QA90 | AP·배포 | 공개 카드 버전 변경 | 기존 매체 승인을 새 버전 승인으로 자동 승격하지 않음 |
| QA91 | AP·배포 | 배치 요청 중복 | 같은 카드 release와 slot 요청은 하나, 다른 body 같은 key 충돌 |
| QA92 | AP·배포 | 매체 승인 권한 | 다른 매체의 slot/placement 승인·조회 불가 |
| QA93 | AP·배포 | 정확한 버전 승인 | 심사 중 카드가 바뀌면409 및 새 버전 검토 요구 |
| QA94 | AP·배포 | 도메인 소유 확인 | 임의 타인 domain 등록으로 embed 서빙 허용 안 됨 |
| QA95 | AP·배포 | slot 비활성/재활성 | 노출 중지, 과거 거절·취소를 자동 승인하지 않음 |
| QA96 | AP·배포 | 공유 링크와 매체 카드 | 기본 link/owned widget은 캠페인·매체 없이 작동. 광고 카드만 공개/매체 버전 승인 필요 |
| QA97 | AP·배포 | frame-ancestors 실제 헤더 | 허용/비허용/중첩 ancestor 각각 별도 origin에서 확인 |
| QA98 | AP·배포 | postMessage origin/source/nonce | 위조·다른 창·wildcard·잘못된 schema 메시지 처리 차단 |
| QA99 | AP·배포 | 제3자 쿠키 없는 카드 | anonymous 안내·접수 전환이 쿠키 차단 환경에서도 가능 |
| QA100 | 연동/AP | handoff 만료·1회 사용 | 기한·audience·session 바인딩 검증, 재사용으로 새 접수 권한 생성 불가 |
| QA101 | 연동/AP | 전환 URL·로그 개인정보 | 전화·사진·대화 text·access secret이 query/Referer/분석에 남지 않음 |
| QA102 | 연동/AP | 외부 카드에서 접수 전환 | 기존 질문·서비스·희망 조건 유지, 연락처는 안전한 접수 화면에서 확인 |
| QA103 | AP·배포 | 위조 attribution | body의 campaign/placement 변경으로 다른 사업자의 성과·문의로 귀속 불가 |
| QA104 | AP·배포 | 매체 PII 차단 | API/CSV/DOM에 이름·전화·사진·원문·개별 접수번호 없음 |
| QA105 | AP·배포 | 작은 집단·차분 집계 | 5개 미만 억제 및 인접 필터 차감 노출 완화, CSV도 동일 |
| QA106 | AP·배포 | 테스트/봇/중복 이벤트 | 명시 테스트·미리보기 제외, 중복 reload/callback이 전환 부풀리지 않음 |
| QA107 | AP·배포 | 예약 성과와 매출 분리 | Field가 보낸 확정 이벤트로 AP 상태/집계를 갱신. 미연결 시 확정 지표는 미지원이며 수금/매출 아님 |
| QA108 | 연동/AP | 개별 카드·AI·전역 중지 | AP AI/카드 중지와 Field 사이트·예약 제한 독립. 연동 grant/작업은 범위별 중지 |
| QA109 | AP·배포 | 노출 후 승인 철회 | 이미 열린 카드의 다음 요청·인계도 거절, 단순 화면 버튼 숨김에 의존하지 않음 |
| QA110 | AP·배포 | 공개키 유출 악용 | 설치 public key로 owner/publisher API 접근 불가, 발급·비용 한도 작동 |
| QA111 | 연동/AP | tenant 교차 지식/캠페인 | 제품별 tenant 격리, 연결 조직 매핑·source/source_id·캐시·큐·도구에서 교차 권한 차단 |
| QA112 | 제품별/공통 | 사진과 자료 재사용 | 고객 첨부가 공개 갤러리·카드·매체 export로 유출되지 않음 |
| QA113 | 연동/AP | 구독 범위와 채널 사용량 | AP와 Field의 구독/크레딧 별도. 연결 동의로 결제/혜택을 자동 복제하지 않음 |
| QA114 | AP·배포 | 제휴 관계 종료 | domain/slot/grant 회수와 기존 업무 보존, 링크 탈취 방지 |
| QA115 | 제품별/공통 | v1.1 마이그레이션 | 기존 v2.0 서버가 있을 때만 원본·조직·대화·동의·과금 이행 검수. 없으면 N/A 근거 기록 |
| QA116 | 제품별/공통 | 운영 빌드 mock 차단 | production에서 mock credentials/role switch/seed fixture 사용시 실패 |
| QA117 | AP | 실제 독립 AI 종단간 | AP만 배포·Field network/env 부재·실제 고객/사업자 두 기기·실LLM/알림/구독으로 완료 |
| QA118 | 연동/AP | 실제 매체 종단간 | AP만으로 별도 origin 광고→상담→접수→집계 완료. Field 연결 예약 경로는 별도 통합 QA |
| QA119 | 제품별/공통 | 역할별 모바일 회귀 | 고객/사업자/매체/관리자 주요행동을320/390px에서14px이상으로 완료 |
| QA120 | 제품별/공통 | 릴리스 인계 증빙 | 제품별 출시/통합증빙·적용160개 QA·독립성·공급사·복구·차단 조건을 표시하고 미실행/skip은 통과로 처리하지 않음 |
| QA121 | AP | AP 완전 독립 실행 | Field 미배포·DB권한/환경값/네트워크 없는 상태에서 가입→설치→접수→응대→구독 완료 |
| QA122 | Field | Field 완전 독립 실행 | AP 미배포·환경값/DB없는 상태에서 자체제작LLM·사이트·직접문의·예약·구독 완료 |
| QA123 | AP/Field | 빌드·마이그레이션 분리 | 상대 앱/마이그레이션 없이 build/migrate/restore; import graph가 공개 client만 허용 |
| QA124 | AP/Field | DB·큐·파일 접근 분리 | 각 runtime credential로 상대 DB/queue/bucket 직접 접근 거부 |
| QA125 | AP/Field | 동일 이메일/카카오 양제품 가입 | 각 조직/세션 생성·별도 동의, token/cookie 자동공유·권한 합침 없음 |
| QA126 | 연동 | 연결과 과금 동의 분리 | OAuth 승인·AI 설치만으로 상대 구독 시작/카드 복제/추가 청구 없음 |
| QA127 | AP | 기본 상담 설치 독립 | campaign/publisher/예약 엔터티 없는 고객이 상담 link와 owned widget을 사용 |
| QA128 | 연동/AP | Field와 일반 외부사이트 동일 계약 | 같은 AP SDK와 공개 권한으로 일반 외부 사이트와 Field 설치, 내부 예외없음 |
| QA129 | 연동 | 연결할 조직/AI 선택 | 양쪽 actor가 선택한 조직/AI만 mapping, 이메일/상호로 자동 연결하지 않음 |
| QA130 | 연동 | 역방향 동의 거부 | AP 설치는 유지하고 Field 사실/예약 도구는 비활성, 취소를 connected로 위장하지 않음 |
| QA131 | 연동 | issuer/audience/token 교환 공격 | AP용 token을 Field API에 제출하거나 반대로 제출 시 거부, code/state/redirect 검수 |
| QA132 | 연동 | 과도한 scope/금지 도구 | AP에서 Field confirm/가격수정/관리자 API 불가; 누락 scope 도구 비노출 |
| QA133 | 연동 | 사람 답변 actor 경계 | Field 소유자가 자신의 AP 위임권한으로 연결 대화만 답변, 타직원·타채널 원문 접근 차단 |
| QA134 | AP/연동 | source 충돌과 편집 권한 | Field source 필드 AP 직접덮어쓰기 금지, native 중복은 명시 mapping·검수 |
| QA135 | 연동 | 사실 발행과 AP 승인 사이 | Field 공개는 독립 완료·AP는 pending_review, 미승인 값을 고객에게 공개하지 않음 |
| QA136 | 연동 | 중요값 최신성 조회 실패 | 가격/시간/활성 상태를 최신이라 단정하지 않고 사람문의 대체, AP native 상담은 유지 |
| QA137 | 연동 | 같은 소스 버전 다른 hash | integrity_conflict로 격리·알림, 승인정보 조용히 덮어쓰기 금지 |
| QA138 | 연동 | 소스 이벤트 역순·누락 | 낮은 revision이 최신을 덮지 않음, snapshot 재조회·재조정 |
| QA139 | 연동 | 외부 요청 timeout 뒤 중복 전송 | 동일 action ID/hash로 한 external_request만, 결과조회 전 새 업무 생성 금지 |
| QA140 | 연동 | 웹훅 서명·재전송·역순 | raw body HMAC·시간창·key rotation·inbox 유일·aggregate 조회·순서 역행 방지 |
| QA141 | 연동 | 최종 고객 전달 동의 | 수신 제품·사업자·항목·정책·조건hash 확인 없이는 전송/알림 없음 |
| QA142 | 연동 | 첨부 수신·URL 악용 | 승인 자산만 인증API로 copy/scan, 임의 URL·다른고객사진 가져오기 거부 |
| QA143 | AP/Field | 원본별 장애 격리 | AP 장애중 Field 원본 메시지/예약과 Field장애중 AP 원본상담을 각각 정상 처리 |
| QA144 | 연동 | Field에서 AP 대화 답변 | AP message ID·sequence·mode 원본 한곳, Field 별도 transcript 작성 없음 |
| QA145 | 연동 | AP 답변 API 실패 | Field가 전송성공/고객수신을 거짓 표시하지 않고 미전송 초안 유지 |
| QA146 | AP/Field | 한 제품 구독 종료 | 상대 구독·원본·기존예약 유지, 자기 신규기능만 정책대로 제한 |
| QA147 | AP/Field | 생산 가격 미확정 | 승인되지 않은 가격/plan으로 청구 불가; mock 금액이 live로 전환되지 않음 |
| QA148 | 연동 | 이벤트별 단일 알림 주체 | AP문의/Field직접문의/연결예약 각각 정해진 제품만 카카오/문자 발송 |
| QA149 | 연동 | 원격 수신과 최종 알림 구분 | 202 inbox ACK·processed·provider success·read를 별도로 표시 |
| QA150 | 연동 | 로컬 revoke 즉시 차단 | 해제 후 로컬 scope/도구/원문조회 차단, 데이터삭제/구독해지로 대체하지 않음 |
| QA151 | 연동 | 원격 장애 중 revoke | 원격토큰 회수대기 durable retry·짧은만료·사용시검사, 완료 오표시 없음 |
| QA152 | 연동/AP | 연결 소스 해제 | Field 소스는 사용중단, AP native로 자동 변환 금지; 다른 native 상담 유지 |
| QA153 | 연동/Field | AP 해제 이후 기존 예약 | 이미 수신한 Field 작업·snapshot 유지; 권한있는 고객 Field 경로/직접연락 제공 |
| QA154 | 연동/AP | 부분 배포 해제 | Field 배포만 중지하고 AP 독립링크·다른 사이트·제휴계약은 자동 삭제하지 않음 |
| QA155 | 연동 | 고객 cross-product 접근 | 유효 AP capability+연결 예약+1회Field handoff만 교환, 전화번호/ID만으론 불가 |
| QA156 | 연동 | 최종 제출 직전 가격/시간 변경 | expected_service_revision mismatch409, 변경내용 고객 재확인 전 자동접수/확정 금지 |
| QA157 | AP/Field | 관리자 제품 경계 | 각 admin MFA·membership·audit, 같은운영자여도 다른 제품 DB/콘솔 자동 접근 금지 |
| QA158 | 연동 | API/schema 버전 독립 배포 | 구 consumer 계약회귀·알수없는필드/enum 처리, breaking change 새버전/이행 |
| QA159 | 공통 | 로그/이벤트/매체 최소정보 | 서명/토큰/연락처/사진/원문이 URL·웹훅·로그·매체 집계에 유출되지 않음 |
| QA160 | 전체 | 제품별 출시 게이트 독립 | A/F/I/D각 증빙과 최종Suite 분리, 아직미완료 모듈을 통합완료라 보고하지 않음 |

### 확정 요구와 검수의 연결

| 요구 | 적용 검수 |
|---|---|
| D01~D04 다양한업종·제작·문의·AI | QA07~24, QA50~80, QA121~128 |
| D05 모바일·PC | QA57~59, QA119, 제품별 실제 핵심 경로 |
| D06~D09 알림·무인증접수 | QA17~21, QA35~41, QA141, QA148~155 |
| D10~D13 사이트·서비스·도메인 | QA07~15, QA53~75, QA134~138 |
| D14~D15 예약·수동일정 | QA25~34, QA139, QA153, QA156 |
| D16~D19 가입·체험·구독·서비스대금 제외 | QA01~06, QA42~49, QA125~126, QA146~147 |
| D20~D21 승인된정보·초안·복구 | QA08~12, QA22~24, QA63~75, QA84~90, QA135~138 |
| 최신 결정: 두 독립 제품·Field 외부설치 | B01~B12 전체, QA121~160 |
| Firsthand식 홍보·매체 역할 | QA87~114, QA118~119, Distribution 게이트 |

### 실제 테스트 결과 기록 형식

```text
QA ID / Product / Release / Commit:
Environment / Browser / Device / Provider mode:
Fixture (synthetic only):
Command and reproduction:
Expected / Actual:
Result: not_run | passed | failed | blocked_integration | not_applicable_with_evidence
Evidence file / logs / screenshots:
Owner / reviewed_at / blocker / next action:
```

현재 이 패키지의 160개 서비스 인수 항목은 **not_run**이다. 문서·JSON 예제·작업 DAG·HTML 보고서 표시 검사는 별도의 `quality_checks/DOCUMENT_QA.md`에만 기록한다.

---

## TASKS — 독립 제품 개발 작업 보드 v3.0

**총 46개 작업. 모든 상태는 planned이며 실제 구현/테스트 완료를 의미하지 않는다.**

C=계약/인프라, A=AP, F=Field, I=연동, D=배포·매체, R=회귀/이행. 이전 T00~T23 통합 작업표를 대체한다. 한 작업을 에이전트 한 번의 실행으로 끝내야 한다는 시간 추정은 아니다. 필요하면 같은 부모 ID 아래 하위 작업으로 나눈다.

| ID | 제품 | 작업 | 선행 | 필수 산출·검수 | QA 연결 |
|---|---|---|---|---|---|
| C00 | 계약/조율 | 저장소·실제 구현·위험 인벤토리 | 없음 | 기존 데이터/코드 유무·권한·보존·변경 범위 ADR | QA115, QA116 |
| C01 | 계약/조율 | 제품 경계·OpenAPI·이벤트·상태·QA 고정 | C00 | B01~B12·양방향 scope·필드·오류 계약·구버전 대응 | QA121~QA160 |
| C02 | 인프라 | 독립 배포/DB/큐/키/CI 프로필 | C01 | AP-only·Field-only 실행과 import/권한 제한 | QA123, QA124 |
| C03 | 디자인 | 공통 무상태 UI·역할별 라우트 설계 | C01 | 14px·모바일·제품 이동·비연결/오류 상태 | QA57, QA58, QA119 |
| A00 | AP | AP 계정·조직·DB·권한 기반 | C02 | 자체 이메일/카카오·세션·AP migrations·outbox | QA01~QA06, QA125 |
| A01 | AP | 직접 지식·서비스·승인 버전 | A00 | source 출처·revision·KnowledgeRelease | QA22, QA81, QA134 |
| A02 | AP | 자체 비회원 접수·대화·사진·접근 | A00 | Field 없는 first-party intake·확인키·합성 테스트 | QA16~QA20, QA41 |
| A03 | AP | 자체 문의함·사람 인계·답변 | A02 | 대화 원본·mode·internal note·단일 발송 이벤트 | QA21, QA41, QA144 |
| A04 | AP | 실제 AI 안내·테스트·가드레일 | A01, A03 | 모델 어댑터·근거·도구 선택·예산·실패 대체 | QA22~QA24, QA117 |
| A05 | AP | 상담 링크·기본 외부 위젯·handoff | A04, C03 | campaign/publisher 없는 설치·origin·기본 SDK | QA94, QA97~QA102, QA127, QA128 |
| A06 | AP | 독립 메시지·푸시·대체발송 | A03 | 실제 공급사·한 발송 주체·원장·미상 처리 | QA35~QA40 |
| A07 | AP | 독립 구독·크레딧·가격 동의 | A00 | AP-only billing·갱신/해지·공급사 검수 | QA42~QA46, QA126, QA146 |
| A08 | AP | AP 관리자·보존/삭제·백업·신고 | A00, A06, A07 | 원본 보존·AP 권한·복구·운영 runbook | QA47~QA49, QA157 |
| A09 | AP | 공식 통합자 API·인가·외부 client 계약 | A01, A03, A05 | AP OAuth server·scope·위임 API·등록 client·문서 | QA129~QA133 |
| A10 | AP | AI Core 단독 실검수 | A05, A06, A07, A08, A09 | Field 없는 실제 외부사이트/실알림/구독·QA 증빙 | QA117, QA121, QA127, QA128 |
| A11 | AP | AI Core 독립 공개 승인 | A10 | G-A1~G-A3·G-L1 적용 증빙·배포/되돌림 | QA121, QA120 |
| F00 | Field | Field 계정·조직·DB·권한 기반 | C02 | 자체 이메일/카카오·세션·Field migrations·outbox | QA01~QA06, QA125 |
| F01 | Field | 사업/서비스·원본 카탈로그 버전 | F00 | 구조화 가격·두 예약 설정·FieldCatalogRelease | QA53, QA77 |
| F02 | Field | 5단계·템플릿·직접 편집·미디어 | F01, C03 | 실입력·다중페이지·사진·재개·모바일 | QA51~QA62, QA70, QA71 |
| F03 | Field | 사이트 제작 LLM·취소·충돌 | F02 | AP없는 제작 어댑터·JSON 제한·작업/비용 | QA54, QA63, QA64, QA122 |
| F04 | Field | 사이트 공개·복구·기본/자체 도메인 | F03 | Field내 원자성·실제 TLS·AP영향 분리 | QA07~QA15, QA65~QA75 |
| F05 | Field | 직접 문의·비회원·사진·후속 접근 | F00, F01 | AP없어도 저장·capability·안전 연락 | QA17~QA20, QA41, QA143 |
| F06 | Field | 직접 문의함·답변·내부 메모 | F05 | 자체 대화 원본·server 상태·outbox | QA41, QA143 |
| F07 | Field | 두 예약 방식·달력·수동 일정 | F01, F06 | 요청/확정·DB충돌·변경·취소·snapshot | QA25~QA34 |
| F08 | Field | 자체 알림·대체발송·이력 | F06, F07 | 자체 공급사 검수·미상·중복·한도 | QA35~QA40 |
| F09 | Field | 구독·관리자·보존·복구 | F00, F04, F08 | 독립 청구/해지·정리모드·Field 운영실 | QA42~QA49, QA146, QA157 |
| F10 | Field | Field Core 단독 실검수 | F04, F07, F08, F09 | AP 없는 사이트→직접문의→예약·실알림·구독 | QA50, QA80, QA122 |
| F11 | Field | Field Core 독립 공개 승인 | F10 | G-F1~G-F3·G-L1 적용 증빙·배포/되돌림 | QA120, QA122 |
| I00 | 연동 | Field 역방향 인가·OAuth 양방향 마법사 | A09, F00 | 서로 다른 token/audience·거부/취소·scope | QA129~QA132 |
| I01 | 연동 | 조직·AI·actor·source 매핑·기능 발견 | I00, A01, F01 | connection ledger·설치만/부분연결·허용리소스 | QA130, QA133, QA134 |
| I02 | 연동 | 승인 정보 sync·최신성·재조정 | I01, F04 | Field source→AP 검토·revision/hash·live 중요값 | QA84, QA135~QA138, QA156 |
| I03 | 연동 | Field 사이트에 외부 SDK 설치 | I01, A05, F04 | 일반외부사이트와동일한 public 계약·origin | QA86, QA94, QA128 |
| I04 | 연동 | 외부 문의/예약 요청·고객 인계 | I01, A02, F07 | 동의·idempotence·unknown·수신 snapshot·Field capability | QA139~QA142, QA153, QA155 |
| I05 | 연동 | Field 문의 통합뷰·AP 답변·알림 소유 | I04, A03, A06, F06, F08 | 원본 API·reply actor·event route·미전달 표시 | QA144, QA145, QA148, QA149 |
| I06 | 연동 | 해제·부분 장애·구독 종료·삭제 | I02, I03, I05 | 양방향 revoke·원격대기·업무보존·새 알림경로 | QA146, QA150~QA155 |
| I07 | 연동 | fault injection·권한/계약 회귀 | I06 | 복수 origin·결과미상·서명재생·scope공격·version 호환 | QA131, QA132, QA140, QA158, QA159 |
| I08 | 연동 | Field Connector 공개 승인 | I07, A11, F11 | G-I1~G-I3·동일 외부 client 계약·고객 E2E | QA50, QA80, QA160 |
| D00 | 배포/매체 | AP 홍보 카드·검토·공개 | A01, A04 | campaign/knowledge 참조·광고표시·revision | QA87~QA91 |
| D01 | 배포/매체 | 매체 조직·도메인·광고 위치 | A00, A09 | 매체 RBAC·소유 증명·slot·AP 관리 | QA92, QA94, QA95 |
| D02 | 배포/매체 | 정확한 카드 버전 배치 승인 | D00, D01 | 사업자공개와매체승인분리·상태·중지 | QA90~QA96 |
| D03 | 배포/매체 | 외부 기사 카드·AP 접수 전환 | A05, D02 | Field 없이 광고 대화→AP 접수·권한/고지 | QA97~QA103, QA118 |
| D04 | 배포/매체 | 성과·개인정보 없는 집계·export | A02, D03 | source event·데모제외·작은집단/차분억제 | QA104~QA107 |
| D05 | 배포/매체 | Distribution 독립 검수·출시 | D04, A10 | G-D1~G-D2·제휴 증빙·AP만으로완료 | QA108~QA114, QA118 |
| R00 | 검수/이행 | 기존120개 재귀속·추가40개 검수 추적 | C01 | QA01~QA160적용제품·게이트·기존변경근거 | QA01~QA160 |
| R01 | 검수/이행 | 기존 서버 존재 시 이행·없으면 N/A 증빙 | C00, I06 | 원본분류·동의·건수·백업·전환·복구 | QA115 |
| R02 | 최종 | 두제품+연동+매체 전체 최종 인수 | A11, F11, I08, D05, R00, R01 | G-S1·독립/연결회귀·릴리스 evidence·운영 인계 | QA120, QA160 |

### 실행 순서와 독립 출시

**C00 → C01 → C02/C03 → A 트랙과 F 트랙 병렬.** AP Core는 A11에서 Field/매체 없이 출시할 수 있다. Field Core는 F11에서 AP 없이 출시할 수 있다. I 트랙은 두 제품의 공개 계약을 이용해 통합하며 I08에서 별도로 승인한다. D05는 AP의 매체 확장 출시이며 Field/연동을 선행으로 요구하지 않는다.

AP A09가 일반 통합자에게 제공하는 인가/API이고, I00는 Field가 외부 리소스 서버로 제공하는 역방향 구현이다. 이를 서로의 런타임 의존으로 합치지 않는다. 실제 API/인증을 구현하기 전에 UI 목업을 만들 수 있으나 해당 task를 verified로 표시할 수는 없다.

R01은 운영 서버/DB가 없다는 인벤토리 증빙이 있으면 not_applicable로 종료한다. 있는 경우 이행 검수는 생략하지 않는다. R02는 모든 제품의 기존 요구가 충족됐는지 검수하며 독립 Core 출시에 영향을 주는 선행 작업이 아니다.

### 모든 작업의 Definition of Done

UI·API·도메인·DB·권한·이벤트·사용량·오류·보안·테스트·롤백이 해당 범위에서 연결되어야 한다. `implemented`는 코드 완료이며 `verified`는 실행 증빙이 있는 상태다. 외부 승인 부재는 blocked_integration이다. QA의 제품별 적용을 생략하거나 다른 제품의 완료로 대체하지 않는다.

API/스키마 변경은 Coordinator가 계약을 승인하고 AP/Field 각 consumer 테스트를 통과한 뒤 병합한다. 공통 migration을 두 제품이 동시에 쓰지 않는다.

### 에이전트별 소유 경로

| 담당 | 기본 소유 | 변경 금지/협의 |
|---|---|---|
| Coordinator | 공개 계약·상태·작업·ADR | DB 직접 병합은 제품 담당 리뷰 |
| AP Agent | agent-web/worker/domain/db | Field 코드 import 금지 |
| Field Agent | field-web/worker/domain/db | AP 코드 import 금지 |
| Connector Agent | generated clients·integration adapter·contract tests | 상대 내부 repository 호출 금지 |
| Distribution Agent | AP campaign/publisher/embed | Field reservation 구현 금지 |
| Reliability | CI·인프라·복구·security/e2e | 게이트 우회·skip을 pass로 처리 금지 |

### 작업 카드 기본 형식

```text
Task / Parent / Product:
State / Owner:
Dependencies / Requirement / QA / Gate:
Allowed paths / Forbidden imports:
Contract inputs and outputs:
Acceptance and failure cases:
Tests run / environment / commit / evidence:
Provider approvals / blockers:
Migration / rollback / handover:
```

---

## AGENTS.md — 독립 AI 플랫폼 + Field, 개발 기준 v3.0

이 패키지는 **개발 명세**다. 운영 앱·실제 외부 연동·상용 배포가 이미 존재한다고 가정하지 않는다. 기존 PRD v2.0과 통합 AGENTS/TASKS는 이력 자료이며 이번 제품 경계와 충돌할 때 사용하지 않는다.

### 1. 먼저 읽을 것

1. `docs/00_PRODUCT_ARCHITECTURE.md`의 B01~B12와 21개 결정.
2. 본인이 담당하는 `docs/01_AGENT_PLATFORM_PRD.md` 또는 `docs/02_FIELD_PRD.md`.
3. `docs/03_INTEGRATION_CONTRACT.md` — 서로의 내부 코드가 아니라 이 계약만 사용.
4. `TASKS.md`의 선행 작업·릴리스·완료 기준.
5. `docs/06_REQUIREMENTS_QA.md`의 적용 QA, `docs/04_SECURITY_OPERATIONS_RELEASE.md`의 게이트.

마스터 문서는 `AI_Field_Service_Operator_Final_Development_Plan_v3.0.md`다. 분할 문서와 내용은 동일 기준이며 변경 시 분할 원문→마스터 재생성 순서를 유지한다. UI v3는 시각·기능 참고일 뿐, 단일 계정·공유 DB·로컬 저장·역할 탭은 운영 아키텍처가 아니다.

### 2. 가장 중요한 구현 규칙

- AP는 Field가 없는 환경에서 가입·AI·지식·외부 설치·상담·알림·결제까지 동작한다.
- Field는 AP가 없는 환경에서 사이트 제작(자체 제작 LLM 포함)·직접 문의·예약·알림·결제까지 동작한다.
- AP/Field domain·repository·DB·identity/session·worker queue·secret을 공유하지 않는다. 같은 monorepo라도 네트워크 계약으로 연결한다.
- Field는 일반 외부 사이트와 같은 AP SDK/공개 API를 사용한다. 내부 DB 우회·고객별 설치 대행·공통 superadmin 금지.
- 기본 AP 상담 위젯에 campaign/publisher/Field booking 의존성을 만들지 않는다.
- Field의 제작 AI와 AP의 고객 상담 AI를 혼동하지 않는다.
- AP 원본 대화는 AP API로 읽고 쓴다. Field 원본 대화는 Field가 유지한다. 원문 양방향 복제로 해결하지 않는다.
- 업무 제출은 고객 동의 후 AP ActionRequest→Field 외부 요청이다. AP는 예약을 확정하지 않는다.
- 연결은 두 방향의 scope·토큰·조직·actor 동의를 가진다. API 토큰을 상대 제품 로그인으로 사용하지 않는다.
- 하나의 사건은 한 제품만 고객/사업자 알림을 보낸다. unknown 상태에서 이중 문자 재발송 금지.
- 제품 간 가격/정보 변경에 공유 DB 트랜잭션을 가정하지 않는다. source revision·검수·중요값 재확인·stale 대체 필수.
- 연결 해제는 양쪽 구독 해지나 데이터 삭제가 아니다. 기존 예약·원본·법정 보존·고객 접근 경로를 유지한다.
- 사이트·지식·카드는 명시 승인 전 초안이다. 숫자/자격/경력/후기를 AI가 만들어 넣지 않는다.
- 고객 OTP·회원가입을 새로 강제하지 않는다. 번호/알림 링크만으로 대화 권한을 주지도 않는다.
- 외부 문서 자동 수집·사진 진단·고객 결제·광고비 정산·임의 MCP 도구는 범위 밖이다.

### 3. 작업과 소유 경로

Coordinator는 schema/API/event/권한 변경과 ADR 병합을 조율한다. AP Agent는 AP 앱/도메인/DB, Field Agent는 Field 앱/도메인/DB, Connector Agent는 공개 HTTP client/bridge/권한 매핑만 담당한다. Distribution Agent는 AP의 campaign/publisher 기능만 다룬다. 한 사람이 순차 실행해도 같은 작업 ID를 사용한다.

공통 UI는 데이터 접근 없는 컴포넌트다. 생성 클라이언트는 버전이 고정된 계약에서만 만든다. 다른 worktree가 수정 중인 migration·DTO를 임의 덮어쓰지 않는다. 변경이 필요한 경우 계약 PR→consumer test→구현 PR 순서다.

저장소가 이미 있으면 구조·잠금 파일·테스트·마이그레이션·운영 데이터 유무부터 조사한다. 기존 코드를 지우고 새 monorepo를 만드는 일을 자동으로 수행하지 않는다. 실제 운영 데이터 복제·삭제·계정 이전·카드 청구·고객 메시지 발송은 별도 권한 없이는 하지 않는다.

### 4. 환경과 상태

`mock`, `sandbox`, `live`를 분리한다. production에 mock·예시 로그인·고정 모델 답변·localStorage 원장·가짜 DNS/결제 성공이 들어가면 부팅/CI가 실패해야 한다.

외부 credential/계약이 없으면 상태는 `blocked_integration`이다. 내부 단위 테스트는 진행할 수 있지만 출시 게이트를 통과 처리하지 않는다. 다른 제품 장애를 검증할 때는 환경변수 제거·네트워크 거부·서버 미배포로 실제 독립성을 검사한다. 빈 fixture를 서버 장애로 대체하지 않는다.

### 5. 저장소에 마련할 검수 명령 계약

다음 명령은 구현팀이 실제 스크립트로 만들어야 한다. 현재 문서 패키지에 서비스 테스트가 구현되어 있다는 뜻이 아니다.

```bash
pnpm lint
pnpm typecheck
pnpm test:unit
pnpm test:db:agent
pnpm test:db:field
pnpm test:contracts
pnpm test:independence:agent
pnpm test:independence:field
pnpm test:integration:faults
pnpm test:e2e:agent
pnpm test:e2e:field
pnpm test:e2e:distribution
pnpm test:security
pnpm build:agent
pnpm build:field
```

`test:independence:agent`는 Field 서비스·DB·비밀값 없이 실제 AP 서버/DB로, 반대도 동일하게 실행한다. `test:integration:faults`는 지연·순서 역전·중복·revoke·scope 거부·결과 미상을 재현한다. 프로덕션 공급사 검수는 별도 gate/evidence로 분리한다.

실패한 테스트를 삭제하거나 기대값을 현재 버그에 맞추지 않는다. 미실행·skip은 그대로 보고한다. 실패가 CI non-zero로 전파되어야 한다. pass 개수만 보고하지 말고 어떤 제품/환경/커밋인지 남긴다.

### 6. UI 및 완료 조건

고객·사업자/서비스 제공자·매체·각 제품 관리자 화면을 유지한다. 글자 최소14px, 본문/입력16px, 모바일320px부터 검수한다. 조작 가능한 버튼에는 실제 API 또는 비활성 사유가 필요하다. UI 입력·저장·반영·공개·전달·확정·발송·열람 상태를 구분한다.

한 작업의 Done은 UI+API+domain+DB+권한+이벤트+사용량+오류+테스트+복구가 연결된 상태다. 코드 완료와 출시 승인은 분리한다. 모든 작업 시작 전 파일 범위·관련 요구/QA·명령을 기록한다.

### 7. 작업 보고 템플릿

```text
Task ID / Product / Owner:
State: planned | in_progress | implemented | blocked | blocked_integration | verified
Requirements / QA / Gate:
Changed paths and reasons:
Contract / schema / migration changes:
Tests actually run, commands, environment, commit:
Not tested and why:
Failure cases and rollback:
External approvals still needed:
Next dependency:
```

### 8. 에이전트 최초 실행 프롬프트

```text
AGENTS.md와 최종 개발 계획 v3.0, TASKS.md를 읽고 현재 저장소를 조사하라.
C00부터 작업한다. AP와 Field는 별도 제품·DB·로그인·구독·배포다.
Field는 정식 외부 클라이언트이고 두 제품 domain/db를 직접 import하지 않는다.
AP 단독 고객은 Field 계정·예약·매체 없이 외부 사이트에 상담 AI를 설치할 수 있어야 한다.
기존 셀프 사이트 제작·두 예약 방식·비회원 접수·역할·최소14px를 유지하라.
먼저 계약/의존성/인프라 격리 검수 계획을 제시하고 승인된 작업 범위 내 구현하라.
미연결 공급사를 성공 모의 처리하지 말고 실제 테스트와 미실행 항목을 구분하라.
이번 턴에서는 선택한 Task의 코드·검수·차단 원인까지 보고하고 출시/청구/삭제를 임의 수행하지 마라.
```

---

**문서 종료 — v3.0 개발 기준. 구현·실서비스 인수 결과는 별도로 기록한다.**

[S01]: https://www.rfc-editor.org/rfc/rfc9700.html
[S02]: https://www.rfc-editor.org/rfc/rfc7009
[S03]: https://developer.mozilla.org/en-US/docs/Web/API/Window/postMessage
[S04]: https://developer.mozilla.org/en-US/docs/Web/HTTP/Reference/Headers/Content-Security-Policy/frame-ancestors
[S05]: https://developer.mozilla.org/en-US/docs/Web/Privacy/Guides/Third-party_cookies
[S06]: https://www.firsthand.ai/platform
